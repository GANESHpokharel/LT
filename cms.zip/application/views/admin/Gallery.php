<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<section id="main" class="column">
<?php
if (isset($status)) {
  echo '<h4 style="width:95%" class="alert_' . $status . '">' . $message . '</h4>';
}
?>
<article class="module width_full">
<header>
<h3 class="tabs_involved">Gallery</h3>
<ul class="tabs">
<li><a href="#tab1">View</a></li>
<li><a href="#tab2">Add</a></li>
</ul>
</header>
<div class="tab_container">
<header>
<h3 class="tabs_involved">Albums</h3>
<div class="clear"></div>
<?php if(isset($album) && (count($album) > 0)) {?>
<ul class="tabs">
<?php foreach($album as $a) {?>
<li><a href="#<?php echo str_replace(' ','_',$a->album_title);?>"><?php echo $a->album_title;?></a></li>
<?php }?>
</ul>
</header>
<div class="tab_container">
<div id="tab1" class="tab_content">
<?php if(isset($gallery) && (count($gallery) > 0 )){
    foreach($gallery as $g) {?>
<div class="gallery">
<img title="<?php echo $g->title;?>" src="<?php echo base_url() . 'uploads/image/' . $g->image;?>"/>
<a href="<?php echo base_url().'Gallery/delete/'.base64_encode(base64_encode($g->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
</div>
<?php }}?>
</div>
<?php foreach($album as $a) {?>
<div id="<?php echo str_replace(' ','_',$a->album_title);?>" class="tab_content">
<?php if(isset($gallery) && (count($gallery) > 0 )){
    foreach($gallery as $g) {
        if($a->id == $g->album_id) {?>
<div class="gallery">
<img src="<?php echo base_url() . 'uploads/image/' . $g->image;?>"/>
<a href="<?php echo base_url().'Gallery/delete/'.base64_encode(base64_encode($g->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
</div>
<?php }}} ?>
</div>
<?php }?>
<div id="tab2" class="tab_content">
<div class="clear"></div>
<form action="<?php echo base_url() . 'Gallery/save';?>" method="POST" enctype="multipart/form-data">
<fieldset style="width: 47%; display: inline;">
<label>Select Album</label>
<select required="required" name="album_id">
<option value="">Please Select Album</option>
<?php foreach($album as $a) {?>
<option value="<?php echo $a->id;?>"><?php echo $a->album_title;?></option>
<?php } ?>
</select>
</fieldset>
<fieldset style="width:47%; float: right;">
<label>Title</label>
<input type="text" name="title"/>
</fieldset>
<fieldset style="width:47%; display: inline; float: left; height: 45px;">
<label>Upload File(s)</label>
<input type="file" name="image[]" multiple="multiple"/>
</fieldset>
<div class="clear"></div>
<div style="margin: 10px;">
<input type="reset" name="reset" value="Reset"/>
<input type="submit" name="submit" value="Submit"/>
</div>
</form>
<?php } else {
    echo '<h4 class="alert_warning">No Album Added. Please Add Album first.</h4>';
    echo '<div class="clear"></div>';
    echo '<div class="spacer"></div>';
} ?>
</div>
</div>
<div class="spacer"></div>
</div>
<div class="spacer"></div>
</article>
</section>