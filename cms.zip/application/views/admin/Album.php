<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<section id="main" class="column">
<?php
if (isset($status)) {
  echo '<h4 style="width:46%" class="alert_' . $status . '">' . $message . '</h4>';
}
?>
<article class="module width_half">
<?php
    $action = 'Album/save';
    $id = '';
    $album_title = '';
    $order = '';
    if (isset($edit)) {
        $action = 'Album/edit_album';
        $id = $edit_details->id;
        $album_title = $edit_details->album_title;
        $order = $edit_details->order;
        ?>
<header>
<h3 class="tabs_involved">Edit album</h3>
<ul class="tabs">
<li><a href="#tab2">Edit</a></li>
<li><a href="<?php echo base_url().'Album'?>">View</a></li>
</ul>
</header>
<?php } else {?>
<header>
<h3 class="tabs_involved">Add Album</h3>
<ul class="tabs">
<li><a href="#tab1">View</a></li>
<li><a href="#tab2">Add</a></li>
</ul>
</header>
<div class="tab_container">
<div id="tab1" class="tab_content">
<?php if(isset($album) && (count($album) > 0)) {?>
<table class="tablesorter" cellspacing="0">
<thead>
<tr>
<th>S.No.</th>
<th>Album Title</th>
<th>Order</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
<?php
$i = 1;
foreach($album as $m) {
?>
<tr>
<td><?php echo $i++ . '.';?></td>
<td><?php echo $m->album_title;?></td>
<td><?php echo $m->order;?></td>
<td>
<a href="<?php echo base_url().'Album/edit/'.base64_encode(base64_encode($m->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_edit.png" title="Edit" />
</a>
<a href="<?php echo base_url().'Album/delete/'.base64_encode(base64_encode($m->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
</td>
</tr>
<?php } ?>
</tbody>
</table>
<?php } else {
    echo '<h4 class="alert_warning">No Album Added. Please Add.</h4>';
} } ?>
</div>
<div id="tab2" class="tab_content">
<form action="<?php echo base_url() . $action;?>" method="POST">
<input type="hidden" name="id" value="<?php echo base64_encode(base64_encode($id))?>"/>
<fieldset>
<label>Album Title</label>
<input type="text" value="<?php echo $album_title;?>" name="album_title" width="95%"/>
</fieldset>
<fieldset>
<label>Order</label>
<input type="text" value="<?php echo $order;?>" name="order" width="95%"/>
</fieldset>
<div class="clear"></div>
<div class="clear"></div>
<div style="margin: 10px;">
<input type="reset" name="reset" value="Reset"/>
<input type="submit" name="submit" value="Submit"/>
</div>
</form>
</div>
</div>
<div class="spacer"></div>
</article>
</section>