<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<section id="main" class="column">
<?php
if (isset($status)) {
  echo '<h4 style="width:46%" class="alert_' . $status . '">' . $message . '</h4>';
}
?>
<article class="module width_half">
<?php
    $action = 'Menu/save';
    $id = '';
    $menu_title = '';
    $has_submenu = '0';
    if (isset($edit)) {
        $action = 'Menu/edit_menu';
        $id = $edit_details->id;
        $menu_title = $edit_details->menu_title;
        $has_submenu = $edit_details->has_submenu;
        ?>
<header>
<h3 class="tabs_involved">Edit Menu</h3>
<ul class="tabs">
<li><a href="#tab2">Edit</a></li>
<li><a href="<?php echo base_url().'Menu'?>">View</a></li>
</ul>
</header>
<?php } else {?>
<header>
<h3 class="tabs_involved">Add Menu</h3>
<ul class="tabs">
<li><a href="#tab1">View</a></li>
<li><a href="#tab2">Add</a></li>
</ul>
</header>
<div class="tab_container">
<div id="tab1" class="tab_content">
<?php if(isset($menu) && (count($menu) > 0)) {?>
<table class="tablesorter" cellspacing="0">
<thead>
<tr>
<th>S.No.</th>
<th>Menu Title</th>
<th>Has Submenu</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
<?php
$i = 1;
foreach($menu as $m) {
?>
<tr>
<td><?php echo $i++ . '.';?></td>
<td><?php echo $m->menu_title;?></td>
<td><?php echo ($m->has_submenu == '1') ? 'Yes' : 'No';?></td>
<td>
<a href="<?php echo base_url().'Menu/edit/'.base64_encode(base64_encode($m->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_edit.png" title="Edit" />
</a>
<a href="<?php echo base_url().'Menu/delete/'.base64_encode(base64_encode($m->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
</td>
</tr>
<?php } ?>
</tbody>
</table>
<?php } else {
    echo '<h4 class="alert_warning">No Menu Added. Please Add.</h4>';
} } ?>
</div>
<div id="tab2" class="tab_content">
<form action="<?php echo base_url() . $action;?>" method="POST">
<input type="hidden" name="id" value="<?php echo base64_encode(base64_encode($id))?>"/>
<fieldset>
<label>Menu Title</label>
<input type="text" value="<?php echo $menu_title;?>" name="menu_title" width="95%"/>
</fieldset>
<div class="clear"></div>
<fieldset>
<label style="width: 100px !important;">Has Submenu</label>
<input type="radio" name="has_submenu" value="1" <?php if($has_submenu == '1'){?> checked="checked" <?php }?>/>Yes
<input type="radio" name="has_submenu" value="0" <?php if($has_submenu == '0'){?> checked="checked" <?php }?>/>No
</fieldset>
<div class="clear"></div>
<div style="margin: 10px;">
<input type="reset" name="reset" value="Reset"/>
<input type="submit" name="submit" value="Submit"/>
</div>
<div class="clear"></div>
</form>
</div>
<div class="spacer"></div>
</div>
</article>
</section>