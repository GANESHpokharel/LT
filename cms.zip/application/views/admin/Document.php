<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<section id="main" class="column">
<?php
if (isset($status)) {
  echo '<h4 style="width:95%" class="alert_' . $status . '">' . $message . '</h4>';
}
?>
<article class="module width_full">
<header>
<h3 class="tabs_involved">Documents</h3>
<ul class="tabs">
<li><a href="#tab1">View</a></li>
<li><a href="#tab2">Add</a></li>
</ul>
</header>
<div class="tab_container">
<div id="tab1" class="tab_content">
<?php if(isset($document) && (count($document) > 0 )){
    foreach($document as $d) {?>
<div class="documnt">
<a title="<?php echo $d->title;?>" target="_blank" href="<?php echo base_url() . 'uploads/docs/' . $d->document;?>">
<img src="<?php echo base_url() . 'admin_assets/images/icon-document.png';?>"/>
</a>
<a class="d_ref" href="<?php echo base_url().'Document/delete/'.base64_encode(base64_encode($d->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
</div>
<?php }} else {
    echo '<h4 class="alert_warning">No Document Added.</h4>';
}?>
</div>
<div id="tab2" class="tab_content">
<form action="<?php echo base_url() . 'Document/save';?>" method="POST" enctype="multipart/form-data">
<fieldset style="width:47%; float: left;">
<label>Title</label>
<input type="text" name="title"/>
</fieldset>
<fieldset style="width:47%; float: right; height: 50px;">
<label style="width: 98%;">Upload File(s)</label>
<input style="margin-left: 10px;" type="file" name="doc[]" multiple="multiple"/>
</fieldset>
<div class="clear"></div>
<div style="margin: 10px;">
<input type="reset" name="reset" value="Reset"/>
<input type="submit" name="submit" value="Submit"/>
</div>
<div class="clear"></div>
</form>
</div>
<div class="spacer"></div>
</div>
</article>
</section>