<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<aside id="sidebar" class="column">
<h3>Manage Contents</h3>
<ul class="toggle">
<li class="icn_new_article"><a href="<?php echo base_url();?>Menu">Menu</a></li>
<li class="icn_new_article"><a href="<?php echo base_url();?>Submenu">Submenu</a></li>
<li class="icn_new_article"><a href="<?php echo base_url();?>Content">Content</a></li>
<li class="icn_new_article"><a href="<?php echo base_url();?>Manage_content">Manage Content</a></li>
<li class="icn_new_article"><a href="<?php echo base_url();?>Radio">Radio</a></li>
<li class="icn_new_article"><a href="<?php echo base_url();?>Member">Our Team</a></li>
</ul>
<h3>Manage Files</h3>
<ul class="toggle">
<li class="icn_new_article"><a href="<?php echo base_url();?>Album">Album</a></li>
<li class="icn_new_article"><a href="<?php echo base_url();?>Gallery">Gallery</a></li>
<li class="icn_new_article"><a href="<?php echo base_url();?>Document">Document</a></li>
</ul>
<h3>Admin Panel</h3>
<ul class="toggle">
<li class="icn_settings"><a href="<?php echo base_url();?>Contact">Contact Information</a></li>
<li class="icn_security"><a href="<?php echo base_url();?>Main/change_password">Change Password</a></li>
<li class="icn_jump_back"><a href="<?php echo base_url();?>Main/manage_users">Manage User</a></li>
<li class="icn_jump_back"><a href="<?php echo base_url();?>Main/manage_files">Manage Files</a></li>
</ul>
<footer>
<hr />
<p><strong>Copyright &copy; 2015 Website Admin</strong></p>
</footer>
</aside>