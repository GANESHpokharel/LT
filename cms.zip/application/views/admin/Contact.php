<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<section id="main" class="column">
<?php
if (isset($status)) {
  echo '<h4 style="width:95%" class="alert_' . $status . '">' . $message . '</h4>';
}
$name = '';
$c_name = '';
$address1 = '';
$address2 = '';
$address3 = '';
$email = '';
$phone1 = '';
$phone2 = '';
$phone3 = '';
$fax = '';
$website_url = '';
$description = '';
if(isset($contact)) {
    $name = $contact->name;
    $c_name = $contact->c_name;
    $address1 = $contact->address1;
    $address2 = $contact->address2;
    $address3 = $contact->address3;
    $email = $contact->email;
    $phone1 = $contact->phone1;
    $phone2 = $contact->phone2;
    $phone3 = $contact->phone3;
    $fax = $contact->fax;
    $website_url = $contact->website_url;
    $description = $contact->description;
}
?>
<article class="module width_full">
<header><h3 class="tabs_involved">Contact Manager</h3></header>
<div class="tab_container">
<div id="tab3" class="tab_content">
<form method="post" action="<?php echo base_url();?>Contact/update_logo" enctype="multipart/form-data">
<fieldset style="width:47%; float: left;">
<label style="width: 100%;">Change ( or Upload ) Company Logo</label>
<input type="file" name="logo" id="complogo" style="margin-left: 2%;"/>
<input type="submit" name="submit" value="Upload"/>
</fieldset>
</form>
<form action="<?php echo base_url();?>Contact/update" method="post">
<fieldset style="width:47%; float: right;">
<label style="width: 25%;">Name</label>
<input type="text" name="name" id="name" value="<?php echo $name;?>"/>
</fieldset>
<div class="clear"></div>
<fieldset style="width:47%; float: left">
<label style="width: 25%;">Company Name</label>
<input type="text" name="c_name" id="c_name" value="<?php echo $c_name;?>"/>
</fieldset>
<fieldset style="width:47%; float: right;">
<label style="width: 25%;">Address 1</label>
<input type="text" name="address1" id="address1" value="<?php echo $address1;?>"/>
</fieldset>
<div class="clear"></div>
<fieldset style="width:47%; float: left;">
<label style="width: 25%;">Address 2</label>
<input type="text" name="address2" id="address2" value="<?php echo $address2;?>"/>
</fieldset>
<fieldset style="width:47%; float: right;">
<label style="width: 25%;">Address 3</label>
<input type="text" name="address3" id="address3" value="<?php echo $address3;?>"/>
</fieldset>
<div class="clear"></div>
<fieldset style="width:47%; float: left;">
<label style="width: 25%;">Email</label>
<input type="text" name="email" id="email" value="<?php echo $email;?>"/>
</fieldset>
<fieldset style="width:47%; float: right;">
<label style="width: 25%;">Phone 1</label>
<input type="text" name="phone1" id="phone1" value="<?php echo $phone1;?>"/>
</fieldset>
<div class="clear"></div>
<fieldset style="width:47%; float: left;">
<label style="width: 25%;">Phone 2</label>
<input type="text" name="phone2" id="phone2" value="<?php echo $phone2;?>"/>
</fieldset>
<fieldset style="width:47%; float: right;">
<label style="width: 25%;">Phone 3</label>
<input type="text" name="phone3" id="phone3" value="<?php echo $phone3;?>"/>
</fieldset>
<div class="clear"></div>
<fieldset style="width:47%; float: left;">
<label style="width: 25%;">Fax</label>
<input type="text" name="fax" id="fax" value="<?php echo $fax;?>"/>
</fieldset>
<fieldset style="width:47%; float: right;">
<label style="width: 25%;">Website URL</label>
<input type="text" name="website_url" id="website_url" value="<?php echo $website_url;?>"/>
</fieldset>
<div class="clear"></div>
<fieldset style="width:96%;">
<label style="width: 25%;">Description</label><br /><br />
<textarea name="description" id="description" class="ckeditor"><?php echo $description;?></textarea>
</fieldset>
<fieldset style="width:48%;">
<input type="submit" name="submit" value="Update" class="alt_btn" style=" margin-left: 2%;"/>
<input type="reset" value="Reset" class="alt_btn"/>
</fieldset><div class="clear"></div>
</form>
</div>
</div>
</article>
<div class="spacer"></div>
</section>