<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<section id="main" class="column">
<?php
if (isset($status)) {
  echo '<h4 style="width:46%" class="alert_' . $status . '">' . $message . '</h4>';
}
?>
<article class="module width_3_quarter">
<?php
    $action = 'Submenu/save';
    $id = '';
    $submenu_title = '';
    $menuid = '0';
    if (isset($edit)) {
        $action = 'Submenu/edit_submenu';
        $id = $edit_details->id;
        $submenu_title = $edit_details->submenu_title;
        $menuid = $edit_details->menu_id;
        ?>
<header>
<h3 class="tabs_involved">Edit SubMenu</h3>
<ul class="tabs">
<li><a href="#tab2">Edit</a></li>
<li><a href="<?php echo base_url().'Submenu'?>">View</a></li>
</ul>
</header>
<?php } else {?>
<header>
<h3 class="tabs_involved">Add SubMenu</h3>
<ul class="tabs">
<li><a href="#tab1">View</a></li>
<li><a href="#tab2">Add</a></li>
</ul>
</header>
<div class="tab_container">
<div id="tab1" class="tab_content">
<?php 
if(isset($submenu) && (count($submenu) > 0)) {
if(isset($menu) && (count($menu) > 0)) {
?>
<table class="tablesorter" cellspacing="0">
<thead>
<tr>
<th>S.No.</th>
<th>Menu Title</th>
<th>SubMenu Title</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
<?php
$i = 1;
foreach($submenu as $sm) {
    foreach($menu as $m) {
        $menu_name = '';
        if($m->id == $sm->menu_id) {
            $menu_name = $m->menu_title;
            break;
        }
    }
?>
<tr>
<td><?php echo $i++ . '.';?></td>
<td><?php echo $menu_name;?></td>
<td><?php echo $sm->submenu_title;?></td>
<td>
<a href="<?php echo base_url().'Submenu/edit/'.base64_encode(base64_encode($sm->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_edit.png" title="Edit" />
</a>
<a href="<?php echo base_url().'Submenu/delete/'.base64_encode(base64_encode($sm->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
</td>
</tr>
<?php } ?>
</tbody>
</table>
<?php } }
    else {
    echo '<h4 class="alert_warning">No SubMenu Added. Please Add.</h4>';
} } ?>
</div>
<div id="tab2" class="tab_content">
<?php if(isset($menu) && (count($menu) > 0)) {?>
<form action="<?php echo base_url() . $action;?>" method="POST">
<input type="hidden" name="id" value="<?php echo base64_encode(base64_encode($id))?>"/>
<fieldset>
<label>Select Menu</label>
<select required="required" name="menu_id">
<option value="">Please Select Menu</option>
<?php foreach($menu as $m) {?>
<option <?php if($m->id == $menuid){?> selected="selected" <?php } ?> value="<?php echo $m->id;?>"><?php echo $m->menu_title;?></option>
<?php } ?>
</select>
</fieldset>
<div class="clear"></div>
<fieldset>
<label>SubMenu Title</label>
<input type="text" value="<?php echo $submenu_title;?>" name="submenu_title" width="95%"/>
</fieldset>
<div class="clear"></div>
<div style="margin: 10px;">
<input type="reset" name="reset" value="Reset"/>
<input type="submit" name="submit" value="Submit"/>
</div>
<div class="clear"></div>
</form>
<?php } else {
    echo '<h4 class="alert_warning">No Menu Found. Please Add Menu first.</h4>';
} ?>
</div>
<div class="spacer"></div>
</div>
</article>
</section>