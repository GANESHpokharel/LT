<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<section id="main" class="column">
<?php
if (isset($status)) {
  echo '<h4 style="width:95%" class="alert_' . $status . '">' . $message . '</h4>';
}
?>
<?php if(isset($manage_user) && ($manage_user == '0')) {?>
<article class="module width_half">
<header>
<h3 class="tabs_involved">Manage Users</h3>
<ul class="tabs">
<li><a href="#tab1">View</a></li>
<?php if(isset($u_id) && ($u_id == '1')) {?>
<li><a href="<?php echo base_url().'Main/add_user';?>">Add User</a></li>
<?php }?>
</ul>
</header>
<div class="tab_container">
<div id="tab1" class="tab_content">
<?php if(isset($user) && (count($user) > 0)){ ?>
<table class="tablesorter" cellspacing="0">
<thead>
<tr>
<th>S.No.</th>
<th>Status</th>
<th>User Name</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
<?php
$i = 1;
foreach($user as $u) {
$can_change = false;
$can_delete = false;
$access = false;
if(isset($u_id) && ($u_id != '')) {
    if(($u->id == $u_id) || ($u_id == '1')) {
        $can_change = true;
    }
    if(($u_id == '1') && ($u->id != '1')) {
        $can_delete = true;        
        $access = true;
    }
    if($u->login == '1') {
        $uicon = base_url().'admin_assets/images/user.png';
        $i_title = 'Online';
    } else {
        $uicon = base_url().'admin_assets/images/icn_profile.png';
        $i_title = 'Offline';
    }
}
?>
<tr>
<td><?php echo $i++ . '.';?></td>
<td><img src="<?php echo $uicon;?>" width="25px;" height="25px;" title="<?php echo $i_title;?>"/></td>
<td><?php echo $u->username;?></td>
<td>
<?php if($can_change) {
    if(($can_change) && ($u_id != $u->id)){?>
<a href="<?php echo base_url().'Main/change_user_password/'.base64_encode(base64_encode($u->id));?>">
<?php } else {?>
<a href="<?php echo base_url().'Main/change_password';?>">
<?php } ?>
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_edit.png" title="Edit" />
</a>
<?php } if($can_delete) {?>
<a href="<?php echo base_url().'Main/delete_user/'.base64_encode(base64_encode($u->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
<?php } if($access) {?>
<a href="<?php echo base_url().'Main/manage_access/'.base64_encode(base64_encode($u->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/key.png" title="Access" />
</a>
<?php } ?>
</td>
</tr>
<?php } ?>
</tbody>
</table>
<?php } else {
    echo '<h4 class="alert_warning">No User Found. Please Add.</h4>';
} ?>
</div>
</div>
<div class="spacer"></div>
</article>
<?php }?>
<?php if(isset($change_password) && ($change_password == '1')) {?>
<article class="module width_half">
<header><h3 class="tabs_involved">Change Password</h3></header>
<div class="tab_container">
<form action="<?php echo base_url().'Main/check_old_passsword';?>" method="POST">
<fieldset>
<label>Enter Previous Password</label>
<input type="password" name="old_password" style="width:92%;"/>
</fieldset><div class="clear"></div>
<input type="reset" value="Reset" style="margin-left: 10px;"/>
<input type="submit" name="submit" value="Change"/>
</form>
</fieldset>
<div class="spacer"></div>
</div>
</article>
<?php }?>
<?php if(isset($change_password) && ($change_password == '2')) {?>
<article class="module width_half">
<header><h3 class="tabs_involved">Change Password</h3></header>
<div class="tab_container">
<form action="<?php echo base_url().'Main/new_passsword';?>" method="POST">
<?php if(isset($user_id) && ($user_id != '')){?>
<input type="hidden" name="user_id" value="<?php echo base64_encode(base64_encode($user_id->id));?>" style="width:92%;"/>
<?php if($user_id->id == '1') {$display = 'display: none;';} else {$display = '';}?>
<fieldset style="<?php echo $display;?>">
<label>Username</label>
<input type="text" name="username" value="<?php echo $user_id->username;?>" style="width:92%;"/>
</fieldset><div class="clear"></div>
<fieldset>
<label>Enter New Password</label>
<input type="password" name="new_password" style="width:92%;"/>
</fieldset><div class="clear"></div>
<fieldset>
<label>Re-Enter Password</label>
<input type="password" name="re_new_password" style="width:92%;"/>
</fieldset>
<input type="reset" value="Reset" style="margin-left: 10px;"/>
<input type="submit" name="submit" value="Change"/>
</form>
</fieldset>
<div class="spacer"></div>
</div>
</article>
<?php }}?>
<?php if(isset($add_user) && ($add_user == '1')) {?>
<article class="module width_half">
<header><h3 class="tabs_involved">Add New User</h3></header>
<div class="tab_container">
<form action="<?php echo base_url().'Main/add_new_user';?>" method="POST">
<fieldset>
<label>Enter User ID</label>
<input type="text" name="username" style="width:92%;"/>
</fieldset><div class="clear"></div>
<fieldset>
<label>Enter Password</label>
<input type="password" name="password" style="width:92%;"/>
</fieldset>
<fieldset>
<label>Re-Enter Password</label>
<input type="password" name="re_password" style="width:92%;"/>
</fieldset>
<input type="reset" value="Reset" style="margin-left: 10px;"/>
<input type="submit" name="submit" value="Add User"/>
</form>
</fieldset>
<div class="spacer"></div>
</div>
</article>
<?php }?>
<?php if(isset($manage_files) && ($manage_files == '1')) {?>
<article class="module width_full">
<header>
<h3 class="tabs_involved">Manage Files</h3>
<ul class="tabs">
<li><a href="#tab1">Image</a></li>
<li><a href="#tab2">Document</a></li>
<li><a href="#tab3">Audio</a></li>
</ul>
</header>
<div class="tab_container">
<div id="tab1" class="tab_content">
<?php if(isset($image) && (count($image) > 0 )){
    foreach($image as $i) {?>
<div class="gallery">
<img src="<?php echo base_url() . 'uploads/image/' . $i;?>"/>
<a href="<?php echo base_url().'Main/delete_image/' . $i;?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
</div>
<?php }}else {
    echo '<h4 class="alert_warning">No Unused Images Found.</h4>';
}?>
<div class="spacer"></div>
</div>
<div id="tab2" class="tab_content">
<?php if(isset($docs) && (count($docs) > 0 )){
    foreach($docs as $d) {?>
<div class="gallery">
<img src="<?php echo base_url() . 'admin_assets/images/icon-document.png';?>"/>
<a href="<?php echo base_url().'Main/delete_doc/' . $d;?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
</div>
<?php }} else {
    echo '<h4 class="alert_warning">No Unused Documents Found.</h4>';
}?>
</div>
<div class="spacer"></div>
<div id="tab3" class="tab_content">
<?php if(isset($audios) && (count($audios) > 0 )){
    foreach($audios as $a) {?>
<div class="gallery">
<img src="<?php echo base_url() . 'admin_assets/images/icon-document.png';?>"/>
<a href="<?php echo base_url().'Main/delete_audio/' . $a;?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
</div>
<?php }} else {
    echo '<h4 class="alert_warning">No Unused Audio Found.</h4>';
}?>
</div>
<div class="spacer"></div>
</div>
</article>
<?php }?>
<?php if(isset($manage_access) && ($manage_access == '1')) {?>
<article class="module width_full">
<header>
<h3 class="tabs_involved">Manage Access For <?php if(isset($user)) {echo ucwords($user->username);} else {}?></h3>
<ul class="tabs">
<li><a href="#tab1">Access</a></li>
</ul>
</header>
<div class="tab_container">
<div id="tab1" class="tab_content">
<form action="<?php echo base_url().'Main/update_access'?>" method="POST">
<table class="tablesorter" cellspacing="0">
<thead>
<tr>
<th>Controllers</th>
<th>Add</th>
<th>View</th>
<th>Edit</th>
<th>Delete</th>
</tr>
</thead>
<tbody>
<?php 
$uarray = explode('/',uri_string());
$user_id = base64_decode(base64_decode($uarray[2]));
foreach ($accesses as $ua) {
    $user = 'user_' . $user_id;
    $access = $ua->$user;
    $create = $access[0];
    $retrieve = $access[1];
    $update = $access[2];
    $delete = $access[3];
?>
<tr>
<input type="hidden" name="user_id" value="<?php echo base64_encode(base64_encode($user_id));?>"/>
<td><?php echo ucwords(str_replace('_',' ', $ua->controller));?></td>
<td><input type="checkbox" name="<?php echo 'create_' . $ua->controller;?>" value="1" <?php if($create == '1'){?> checked="checked" <?php }?>/></td>
<td><input type="checkbox" name="<?php echo 'retrieve_' . $ua->controller;?>" value="1" <?php if($retrieve == '1'){?> checked="checked" <?php }?>/></td>
<td><input type="checkbox" name="<?php echo 'update_' . $ua->controller;?>" value="1" <?php if($update == '1'){?> checked="checked" <?php }?>/></td>
<td><input type="checkbox" name="<?php echo 'delete_' . $ua->controller;?>" value="1" <?php if($delete == '1'){?> checked="checked" <?php }?>/></td>
</tr>
<?php
unset($ua);
unset($create);
unset($retrieve);
unset($update);
unset($delete);
}?>
</tbody>
</table>
<div style="float: right;">
<input type="submit" name="submit" value="Update"/>
</div>
</form>
</div>
<div class="spacer"></div>
</div>
</article>
<?php }?>
<div class="spacer"></div>
</section>