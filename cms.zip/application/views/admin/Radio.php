<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<section id="main" class="column">
<?php
if (isset($status)) {
  echo '<h4 style="width:95%" class="alert_' . $status . '">' . $message . '</h4>';
}
?>
<article class="module width_full">
<?php
    $action = 'Radio/save';
    $id = '';
    $title = '';
    $subtitle = '';
    $link = ''; 
    $description = '';
    $date_and_time = '';
    if (isset($edit)) {
        $action = 'Radio/edit_content';
        $id = $edit_details->id;        
        $title = $edit_details->title;
        $subtitle = $edit_details->subtitle;
        $link = $edit_details->link;
        $description = $edit_details->description;
        $date_and_time = $edit_details->date_and_time;
        ?>
<header>
<h3 class="tabs_involved">Edit Radio Contents</h3>
<ul class="tabs">
<li><a href="#tab2">Edit</a></li>
<li><a href="<?php echo base_url().'Radio'?>">View</a></li>
</ul>
</header>
<?php } else {?>
<header>
<h3 class="tabs_involved">Add Radio Contents</h3>
<ul class="tabs">
<li><a href="#tab1">View</a></li>
<li><a href="#tab2">Add</a></li>
</ul>
</header>
<div class="tab_container">
<div id="tab1" class="tab_content">
<?php if(isset($radio) && (count($radio) > 0)) {?>
<table class="tablesorter" cellspacing="0">
<thead>
<tr>
<th>S.No.</th>
<th>Title</th>
<th>Post Date</th>
<th>Image</th>
<th>Audio</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
<?php
$i = 1;
foreach ($radio as $mc) {
?>
<tr>
<td><?php echo $i++ . '.';?></td>
<td><?php echo $mc->title;?></td>
<td><?php echo $mc->date_and_time;?></td>
<td>
<?php if($mc->image == ''){?>
<form method="POST" action="<?php echo base_url().'Radio/upload_image';?>" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?php echo base64_encode(base64_encode($mc->id));?>"/>
<input required="required" type="file" name="image" style="width: 75px !important;"/><br />
<input type="submit" name="submit" value="Upload"/>
</form>
<?php } else {?>
<div class="cont_img">
<img src="<?php echo base_url().'uploads/image/'.$mc->image;?>"/>
<a href="<?php echo base_url().'Radio/delete_image/'.base64_encode(base64_encode($mc->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
</div>
<?php }?>
</td>
<td>
<?php if($mc->audio == ''){?>
<form method="POST" action="<?php echo base_url().'Radio/upload_audio';?>" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?php echo base64_encode(base64_encode($mc->id));?>"/>
<input required="required" type="file" name="audio" style="width: 75px !important;"/><br />
<input type="submit" name="submit" value="Upload"/>
</form>
<?php } else {?>
<div class="cont_img">
<img src="<?php echo base_url().'admin_assets/images/icon-document.png';?>"/>
<a href="<?php echo base_url().'Radio/delete_audio/'.base64_encode(base64_encode($mc->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
</div>
<?php }?>
</td>
<td>
<a href="<?php echo base_url().'Radio/edit/'.base64_encode(base64_encode($mc->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_edit.png" title="Edit" />
</a>
<a href="<?php echo base_url().'Radio/delete/'.base64_encode(base64_encode($mc->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
</td>
</tr>
<?php } ?>
</tbody>
</table>
<?php } else {
    echo '<h4 class="alert_warning">No Content Found. Please Add.</h4>';
} } ?>
</div>
<div id="tab2" class="tab_content">
<form action="<?php echo base_url() . $action;?>" method="POST">
<input type="hidden" name="id" value="<?php echo base64_encode(base64_encode($id))?>"/>
<fieldset style="width:47.5%; display: inline;">
<label style="width: 25%;">Title</label>
<input type="text" name="title" value="<?php echo $title;?>"/>
</fieldset>
<fieldset style="width:47.5%; display: inline;">
<label style="width: 25%;">Subtitle</label>
<input type="text" name="subtitle" value="<?php echo $subtitle;?>"/>
</fieldset>
<fieldset style="width:47.5%; display: inline;">
<label style="width: 25%;">Date And Time</label>
<input type="text" name="date_and_time" value="<?php echo $date_and_time;?>"/>
</fieldset>
<fieldset style="width:47.5%; display: inline;">
<label style="width: 25%;">Link</label>
<input type="text" name="link" value="<?php echo $link;?>"/>
</fieldset>
<fieldset style="width:98%; display: inline;">
<label style="width: 25%;">Desctiption</label>
<div class="clear"></div>
<textarea class="ckeditor" name="description"><?php echo $description;?></textarea>
</fieldset>
<div class="clear"></div>
<div style="margin: 10px;">
<input type="reset" name="reset" value="Reset"/>
<input type="submit" name="submit" value="Submit"/>
</div>
</form>
</div>
<div class="spacer"></div>
</div>
</article>
</section>