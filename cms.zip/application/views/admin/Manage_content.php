<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<section id="main" class="column">
<?php
if (isset($status)) {
  echo '<h4 style="width:95%" class="alert_' . $status . '">' . $message . '</h4>';
}
?>
<article class="module width_full">
<?php
    $action = 'Manage_content/save';
    $id = '';
    $content_type = '';
    $content_id = '';
    $title = '';
    $subtitle = '';
    $link = ''; 
    $description = '';
    $display = 'none';
    $menuid = '';
    $content_list = '';
    if (isset($edit)) {
        $action = 'Manage_content/edit_content';
        $content_type = $edit_details->content_type;
        if ($content_type == 'submenu') {
            $display = 'inline';
            $menuid = $menu_id;
        }
        $content_list = $contents_list;
        $content_id = $edit_details->content_id;
        $id = $edit_details->id;        
        $title = $edit_details->title;
        $subtitle = $edit_details->subtitle;
        $link = $edit_details->link;
        $description = $edit_details->description;
        ?>
<header>
<h3 class="tabs_involved">Edit Manage Contents</h3>
<ul class="tabs">
<li><a href="#tab2">Edit</a></li>
<li><a href="<?php echo base_url().'Manage_content'?>">View</a></li>
</ul>
</header>
<?php } else {?>
<header>
<h3 class="tabs_involved">Add Manage Contents</h3>
<ul class="tabs">
<li><a href="#tab1">View</a></li>
<li><a href="#tab2">Add</a></li>
</ul>
</header>
<div class="tab_container">
<div id="tab1" class="tab_content">
<?php if(isset($manage_content) && (count($manage_content) > 0)) {?>
<table class="tablesorter" cellspacing="0">
<thead>
<tr>
<th>S.No.</th>
<th>Content Type</th>
<th>Content</th>
<th>Title</th>
<th>Description</th>
<th>Image1</th>
<th>Image2</th>
<th>Doc1</th>
<th>Doc2</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
<?php
$i = 1;
foreach ($manage_content as $mc) {
    $cid = '';
    if($mc->content_type == 'menu') {
        foreach($menu as $m) {
            if($m->id == $mc->content_id) {
                $cid = $m->menu_title;
                break;
            }
        }
    }
    if($mc->content_type == 'submenu') {
        foreach($submenu as $sm) {
            if($sm->id == $mc->content_id) {
                $cid = $sm->submenu_title;
                break;
            }
        }
    }
    if($mc->content_type == 'content') {
        foreach($content as $c) {
            if($c->id == $mc->content_id) {
                $cid = $c->content_title;
                break;
            }
        }
    }
?>
<tr>
<td><?php echo $i++ . '.';?></td>
<td><?php echo ucwords($mc->content_type);?></td>
<td><?php echo $cid;?></td>
<td><?php echo $mc->title;?></td>
<td><?php echo substr($mc->description, 0, 10).'...';?></td>
<td>
<?php if($mc->img1 == ''){?>
<form method="POST" action="<?php echo base_url().'Manage_content/upload_img';?>" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?php echo base64_encode(base64_encode($mc->id));?>"/>
<input required="required" type="file" name="img1" style="width: 75px !important;"/><br />
<input type="submit" name="submit" value="Upload"/>
</form>
<?php } else {?>
<div class="cont_img">
<img src="<?php echo base_url().'uploads/image/'.$mc->img1;?>"/>
<a href="<?php echo base_url().'Manage_content/delete_img/'.base64_encode(base64_encode($mc->id)).'/img1';?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
</div>
<?php }?>
</td>
<td>
<?php if($mc->img2 == ''){?>
<form method="POST" action="<?php echo base_url().'Manage_content/upload_img';?>" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?php echo base64_encode(base64_encode($mc->id));?>"/>
<input required="required" type="file" name="img2" style="width: 75px !important;"/><br />
<input type="submit" name="submit" value="Upload"/>
</form>
<?php } else {?>
<div class="cont_img">
<img src="<?php echo base_url().'uploads/image/'.$mc->img2;?>"/>
<a href="<?php echo base_url().'Manage_content/delete_img/'.base64_encode(base64_encode($mc->id)).'/img2';?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
</div>
<?php }?>
</td>
<td>
<?php if($mc->doc1 == ''){?>
<form method="POST" action="<?php echo base_url().'Manage_content/upload_doc';?>" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?php echo base64_encode(base64_encode($mc->id));?>"/>
<input required="required" type="file" name="doc1" style="width: 75px !important;"/><br />
<input type="submit" name="submit" value="Upload"/>
</form>
<?php } else {?>
<div class="cont_img">
<img src="<?php echo base_url().'admin_assets/images/icon-document.png';?>"/>
<a href="<?php echo base_url().'Manage_content/delete_doc/'.base64_encode(base64_encode($mc->id)).'/doc1';?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
</div>
<?php }?>
</td>
<td>
<?php if($mc->doc2 == ''){?>
<form method="POST" action="<?php echo base_url().'Manage_content/upload_doc';?>" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?php echo base64_encode(base64_encode($mc->id));?>"/>
<input required="required" type="file" name="doc2" style="width: 75px !important;"/><br />
<input type="submit" name="submit" value="Upload"/>
</form>
<?php } else {?>
<div class="cont_img">
<img src="<?php echo base_url().'admin_assets/images/icon-document.png';?>"/>
<a href="<?php echo base_url().'Manage_content/delete_doc/'.base64_encode(base64_encode($mc->id)).'/doc2';?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
</div>
<?php }?>
</td>
<td>
<a href="<?php echo base_url().'Manage_content/edit/'.base64_encode(base64_encode($mc->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_edit.png" title="Edit" />
</a>
<a href="<?php echo base_url().'Manage_content/delete/'.base64_encode(base64_encode($mc->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
</td>
</tr>
<?php } ?>
</tbody>
</table>
<?php } else {
    echo '<h4 class="alert_warning">No Content Found. Please Add.</h4>';
} } ?>
</div>
<div id="tab2" class="tab_content">
<form action="<?php echo base_url() . $action;?>" method="POST">
<input type="hidden" name="id" value="<?php echo base64_encode(base64_encode($id))?>"/>
<fieldset style="width: 47.5%; float: left; height: 100%;">
<label>Select Content Type</label>
<select name="content_type" id="content_type" required="required">
<option value="">Please Select Content Type</option>
<option value="content" <?php if($content_type == 'content'){?> selected="selected" <?php } ?>>Content</option>
<option value="menu" <?php if($content_type == 'menu'){?> selected="selected" <?php } ?>>Menu</option>
<option value="submenu" <?php if($content_type == 'submenu'){?> selected="selected" <?php } ?>>Submenu</option>
</select>
</fieldset>
<fieldset id="menu_list" style="width: 47.5%; display: <?php echo $display;?>; height: 100%;">
<label>Select Menu</label>
<select id="menu_id" name="menu_id">
<option value="">Please Select Menu</option>
<?php if(isset($menu_s) && (count($menu_s) > 0)) {
    foreach($menu_s as $m) {?>
<option value="<?php echo base64_encode(base64_encode($m->id));?>" <?php if($m->id == $menuid){?> selected="selected" <?php }?>><?php echo $m->menu_title;?></option>
<?php }}?>
</select>
</fieldset>
<fieldset style="width: 47.5%; float: left; height: 100%;">
<label>Select Content</label>
<select id="content_id" name="content_id" required="required">
<option value="">Please Select Content</option>
<?php if(isset($content_list) && (count($content_list) > 0)) {
    $ctitle = $content_type . '_title';
    foreach($content_list as $cl) {
?>
<option value="<?php echo $cl->id;?>" <?php if($cl->id == $content_id){?> selected="selected" <?php }?> ><?php echo $cl->$ctitle;?></option>
<?php } }?>
</select>
</fieldset>
<fieldset style="width:47.5%; display: inline;">
<label style="width: 25%;">Title</label>
<input type="text" name="title" value="<?php echo $title;?>"/>
</fieldset>
<fieldset style="width:47.5%; display: inline;">
<label style="width: 25%;">subtitle</label>
<input type="text" name="subtitle" value="<?php echo $subtitle;?>"/>
</fieldset>
<fieldset style="width:47.5%; display: inline;">
<label style="width: 25%;">Link</label>
<input type="text" name="link" value="<?php echo $link;?>"/>
</fieldset>
<fieldset style="width:98%; display: inline;">
<label style="width: 25%;">Desctiption</label>
<div class="clear"></div>
<textarea class="ckeditor" name="description"><?php echo $description;?></textarea>
</fieldset>
<div class="clear"></div>
<div style="margin: 10px;">
<input type="reset" name="reset" value="Reset"/>
<input type="submit" name="submit" value="Submit"/>
</div>
</form>
</div>
<div class="spacer"></div>
</div>
</article>
</section>
<script type="text/javascript">
jQuery(document).ready(function () {
  jQuery('#content_type').change(function () {
    jQuery('#menu_id').val('');
    jQuery('#menu_list').hide();
    jQuery('#content_id > option').remove();
    if(this.value == 'submenu') {
        jQuery('#menu_list').css('display', 'inline');
    } else {
        jQuery.ajax({
            type: 'POST',
            url: '<?php echo base_url();?>Manage_content/content_list/no/' + this.value,
            success: function (data) {
                jQuery('#content_id').append(data);
            }
        });
    }
  });
  jQuery('#menu_id').change(function () {
    jQuery('#content_id > option').remove();    
    jQuery.ajax({
        type: 'POST',
        url: '<?php echo base_url();?>Manage_content/content_list/yes/' + this.value,
        success: function (data) {
            jQuery('#content_id').append(data);
        }
    });    
  });
});
</script>