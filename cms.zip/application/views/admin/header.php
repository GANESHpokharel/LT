<?php
error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');
$session = $this->session->all_userdata();
if (!isset($session['sess_name'])) {
    $this->session->sess_destroy();
    redirect('Login');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<title><?php if(isset($title)) {echo $title;} else {echo 'Content Management System';}?></title>
<link rel="stylesheet" href="<?php echo base_url();?>admin_assets/css/layout.css" type="text/css" media="screen" />
<script src="<?php echo base_url();?>admin_assets/js/jquery-2.1.4.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>admin_assets/js/hideshow.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>admin_assets/js/jquery.tablesorter.min.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/jquery.equalHeight.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/ckeditor/ckeditor.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('.tablesorter').tablesorter();
    });
    $(document).ready(function () {
        $('.tab_content').hide();
        $('ul.tabs li:first').addClass('active').show();
        $('.tab_content:first').show();
        $('ul.tabs li').click(function () {
        $('ul.tabs li').removeClass('active');
        $(this).addClass('active');
        $('.tab_content').hide();
        var activeTab = $(this).find('a').attr('href');
        $(activeTab).fadeIn();
        return false;
        });
    });
</script>
<script type="text/javascript">
    $(function(){
        $('.column').equalHeight();
    });
</script>
</head>
<body>
<header id="header">
    <hgroup>
        <h1 class="site_title"></h1>
        <h2 class="section_title">Welcome To Content Management System</h2>
        <div class="btn_view_site"><a href="<?php echo base_url();?>Login/user_logout">Logout</a></div>
    </hgroup>
</header>
<section id="secondary_bar">
    <div class="user"><p><?php echo $session['sess_name'];?></p>
    </div>
    <div class="breadcrumbs_container">
        <article class="breadcrumbs">
        <a href="<?php echo base_url();?>Main">Home</a>
        <?php $uri_str = uri_string();
        $url_arr = explode('/', $uri_str);
        $url = base_url();
        foreach($url_arr as $key => $ur){
            if($ur != 'Main') {
                if($ur == 'edit' || $key == 2) {
                    break;
                }?>
            <div class="breadcrumb_divider"></div>
            <a href=""><?php echo ucwords(str_replace('_', ' ', $ur));?></a>
            <?php }}?>
        </article>
    </div>
</section>