<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<section id="main" class="column">
<?php
if (isset($status)) {
  echo '<h4 style="width:46%" class="alert_' . $status . '">' . $message . '</h4>';
}
?>
<article class="module width_half">
<?php
    $action = 'Content/save';
    $id = '';
    $content_title = '';
    if (isset($edit)) {
        $action = 'Content/edit_content';
        $id = $edit_details->id;
        $content_title = $edit_details->content_title;
        ?>
<header>
<h3 class="tabs_involved">Edit content</h3>
<ul class="tabs">
<li><a href="#tab2">Edit</a></li>
<li><a href="<?php echo base_url().'Content'?>">View</a></li>
</ul>
</header>
<?php } else {?>
<header>
<h3 class="tabs_involved">Add Content</h3>
<ul class="tabs">
<li><a href="#tab1">View</a></li>
<li><a href="#tab2">Add</a></li>
</ul>
</header>
<div class="tab_container">
<div id="tab1" class="tab_content">
<?php if(isset($content) && (count($content) > 0)) {?>
<table class="tablesorter" cellspacing="0">
<thead>
<tr>
<th>S.No.</th>
<th>Content Title</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
<?php
$i = 1;
foreach($content as $m) {
?>
<tr>
<td><?php echo $i++ . '.';?></td>
<td><?php echo $m->content_title;?></td>
<td>
<a href="<?php echo base_url().'Content/edit/'.base64_encode(base64_encode($m->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_edit.png" title="Edit" />
</a>
<a href="<?php echo base_url().'Content/delete/'.base64_encode(base64_encode($m->id));?>">
<input type="image" src="<?php echo base_url();?>admin_assets/images/icn_trash.png" title="Delete" />
</a>
</td>
</tr>
<?php } ?>
</tbody>
</table>
<?php }else {
    echo '<h4 class="alert_warning">No Content Found. Please Add.</h4>';
} } ?>
</div>
<div id="tab2" class="tab_content">
<form action="<?php echo base_url() . $action;?>" method="POST">
<input type="hidden" name="id" value="<?php echo base64_encode(base64_encode($id))?>"/>
<fieldset>
<label>Content Title</label>
<input type="text" value="<?php echo $content_title;?>" name="content_title" width="95%"/>
</fieldset>
<div class="clear"></div>
<div class="clear"></div>
<div style="margin: 10px;">
<input type="reset" name="reset" value="Reset"/>
<input type="submit" name="submit" value="Submit"/>
</div>
<div class="clear"></div>
</form>
</div>
<div class="spacer"></div>
</div>
</article>
</section>