<?php
error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE HTML>
<html>
<head>
<title><?php if(isset($title)) {echo $title;} else {echo 'Login';}?></title>
<link href="<?php echo base_url();?>admin_assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
	<div class="login">
	<div class="login-box1 box effect6">
		<div class="login-top">
				<h2>Member Login</h2>
			<div class="user">
				<img src="<?php echo base_url();?>admin_assets/images/user.png" alt=""/>
			</div>
		   <div class="clear"> </div>
		</div>
		<div class="login-bottom">
        <form action="<?php echo base_url();?>Login/user_login" method="POST">
        <?php if(isset($status)) {
            echo '<h4 class="alert_' . $status . '">' . $message . '</h4>';
         }?>
			<input type="text" name="username" placeholder="Username" />
			<input type="password" name="password" placeholder="Password"/>
			<div class="send">
				<div class="now"><input type="submit" name="submit" value="Login"/></div>
			</div>
            </form>
		</div>
	</div>
</div>	
</body>
</html>