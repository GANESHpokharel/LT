<?php
//Connect to database
$db_name = 'pf';
$user = 'root';
$pass = '';
$dbh = new PDO('mysql:host=localhost;dbname=' . $db_name, $user, $pass);
if ($dbh && (gettype($dbh) == 'object')) {
    return $dbh;
} else {
  return false;
}
