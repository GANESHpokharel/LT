<div class="slider-bottom" style="background: #38761d;">
<?php
if (isset($message)) {
  echo '<h4 class="message_' . $status . '">' . $message . '</h4>';
}
?>
<h3>Request for Service</h3><br />
<h4>(To be filled by the clients)</h4><br />
<h5><span class="required_f">*</span> आवश्यक छ</h5>
<form method="POST" action="<?php echo base_url();?>Dashboard/register_service">
<table>
<tr><td><label>Your Name: <span class="required_f"><span class="required_f">*</span></span></label></td></tr>
<tr><td><input required="required" type="text" name="name"/></td></tr>
<tr><td></td></tr>
<tr><td><label>Name of the Entity: <span class="required_f">*</span></label></td></tr>
<tr><td><input required="required" type="text" name="e_name"/></td></tr>
<tr><td></td></tr>
<tr><td><label>Type of the Entity: <span class="required_f">*</span></label></td></tr>
<tr><td><input type="radio" value="Pvt. Ltd." name="type"/>&nbsp;<span class="input_value">Pvt. Ltd.</span></td></tr>
<tr><td><input type="radio" value="Public Ltd." name="type"/>&nbsp;<span class="input_value">Public Ltd.</span></td></tr>
<tr><td><input type="radio" value="Proprietorship/Partnership" name="type"/>&nbsp;<span class="input_value">Proprietorship/Partnership</span></td></tr>
<tr><td><input type="radio" value="NGO/INGO" name="type"/>&nbsp;<span class="input_value">NGO/INGO</span></td></tr>
<tr><td><input type="radio" value="Personal" name="type"/>&nbsp;<span class="input_value">Personal</span></td></tr>
<tr><td><input type="radio" value="others" name="type"/>&nbsp;<span class="input_value">अन्य: &nbsp;<input type="text" id="type_d" name="type_d"/></td></tr>
<tr><td></td></tr>
<tr><td><label>Type of Service Required: <span class="required_f">*</span></label></td></tr>
<tr><td><input type="radio" value="Statutory Audit" name="service_type"/>&nbsp;<span class="input_value">Statutory Audit</span></td></tr>
<tr><td><input type="radio" value="Internal Audit" name="service_type"/>&nbsp;<span class="input_value">Internal Audit</span></td></tr>
<tr><td><input type="radio" value="IT Audit" name="service_type"/>&nbsp;<span class="input_value">IT Audit</span></td></tr>
<tr><td><input type="radio" value="Tax Consultancy" name="service_type"/>&nbsp;<span class="input_value">Tax Consultancy</span></td></tr>
<tr><td><input type="radio" value="Liquidation of Business" name="service_type"/>&nbsp;<span class="input_value">Liquidation of Business</span></td></tr>
<tr><td><input type="radio" value="Merger/Acquisition/Takeover" name="service_type"/>&nbsp;<span class="input_value">Merger/Acquisition/Takeover</span></td></tr>
<tr><td><input type="radio" value="Valuation of Share" name="service_type"/>&nbsp;<span class="input_value">Valuation of Share</span></td></tr>
<tr><td><input type="radio" value="Fraud Investigation" name="service_type"/>&nbsp;<span class="input_value">Fraud Investigation</span></td></tr>
<tr><td><input type="radio" value="System Migration" name="service_type"/>&nbsp;<span class="input_value">System Migration</span></td></tr>
<tr><td><input type="radio" value="Microsoft Excel Training" name="service_type"/>&nbsp;<span class="input_value">Microsoft Excel Training</span></td></tr>
<tr><td><input type="radio" value="Business Continuity Planning" name="service_type"/>&nbsp;<span class="input_value">Business Continuity Planning</span></td></tr>
<tr><td><input type="radio" value="Disaster Recovery Planning" name="service_type"/>&nbsp;<span class="input_value">Disaster Recovery Planning</span></td></tr>
<tr><td><input type="radio" value="Book Writing" name="service_type"/>&nbsp;<span class="input_value">Book Writing</span></td></tr>
<tr><td><input type="radio" value="others" name="service_type"/>&nbsp;<span class="input_value">अन्य: &nbsp;<input type="text" id="service_type_d" name="service_type_d"/></td></tr>
<tr><td></td></tr>
<tr><td><label>Your Mobile Number: <span class="required_f">*</span></label></td></tr>
<tr><td><input required="required" type="text" name="mobile"/></td></tr>
<tr><td></td></tr>
<tr><td><label>Your Phone Number (Office):</label></td></tr>
<tr><td><input required="required" type="text" name="office"/></td></tr>
<tr><td></td></tr>
<tr><td><label>Your E-mail: <span class="required_f">*</span></label></td></tr>
<tr><td><input required="required" type="text" name="email"/></td></tr>
<tr><td></td></tr>
<tr><td><label>Please mention below the short description of service required from us:</label></td></tr>
<tr><td><textarea rows="5" cols="65" name="description"></textarea></td></tr>
<tr><td></td></tr>
<tr><td><label>Confirmation Number: <span class="required_f">*</span></label></td></tr>
<tr><td><span class="input_value">5 digit number, which is messaged to your mobile number</span></td></tr>
<tr><td><input required="required" type="text" name="confirmation"/></td></tr>
<tr><td><input type="submit" name="submit" value="पेस गर्नुहोस्"/></td></tr>
</table>
</form>
<div class="clearfix"></div>
</div>
<script type="text/javascript">
jQuery(document).ready(function() {
    jQuery('input:radio').click(function() {
        jQuery('#type_d').attr('required', false);
        jQuery('#service_type_d').attr('required', false);
        var radio_type = jQuery(this).attr('name');
        var type_value = jQuery(this).val();
        if (type_value == 'others') {
            if (radio_type == 'type') {
                jQuery('#type_d').attr('required', true);
            }
            if (radio_type == 'service_type') {
                jQuery('#service_type_d').attr('required', true);
            }
        }
    });
});
</script>
<style type="text/css">
.message_success {
    background: #b6d7a8;
    height: 35px;
    border-radius: 5px;
    color: #38761d;
    padding: 7px;
}
.message_error {
    background: #b6d7a8;
    height: 35px;
    border-radius: 5px;
    color: #ce0000;
    padding: 7px;
}
h3,h4,label, .input_value{
    color: #ffffff;
}
h5, .required_f{
    color: #ffd9a8;
}
input[type=text] {
    width: 250px;
}
table tr {
    line-height: 30px;
    margin: 10px;
}
</style>