<div class="slider-bottom" style="width: 100% !important;">
<div>
<div style="float: left; margin-right: 20px;">
<h3>Google Map of Our Office</h3>
</div>
<div style="float: right;">
<h3><a style="outline: 0;" target="_blank" href="<?php echo base_url().'Dashboard/request_service';?>">Click Here for our Services</a></h3>
</div>
</div>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d33612.840503613166!2d85.38298573586623!3d27.68285159321323!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjfCsDQwJzMzLjkiTiA4NcKwMjInMTkuNiJF!5e0!3m2!1sen!2snp!4v1440318730073" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
<?php if(isset($contact)) {?>
<p class="map_contact">Address: <?php echo $contact->address1.', '.$contact->address2.', '.$contact->address3;?></p>		
<p class="map_contact">Post Box No. : <?php echo $contact->fax;?></p>		
<p class="map_contact">Phone : <?php echo $contact->phone1.', '.$contact->phone2;?></p>
<p class="map_contact">E-mail: <?php echo $contact->email;?></p>
<p class="map_contact">Web: <?php echo $contact->website_url;?></p>
<?php }?>
<div class="clearfix"></div>
</div>
<style type="text/css">
.map_contact {
    font-size: 18px;
}
</style>