<div class="footer">
			<p><img src="<?php echo base_url();?>/site_assets/images/footer.jpg" width="100%"/></p>
		</div>
	</div>
</div>
<!-- //content -->
</body>
</html>