<?php error_reporting(0);?>
<!DOCTYPE html>
<html>
<head>
<title><?php if(isset($title)){echo $title;}else{echo 'G Kattel & Associates';}?></title>
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'/>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'/>
<!--//fonts-->
<link href="<?php echo base_url();?>/site_assets/css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="<?php echo base_url();?>/site_assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<script type="application/x-javascript">
addEventListener("load", function() {
setTimeout(hideURLbar, 0);}, false);
function hideURLbar() {
    window.scrollTo(0,1);
} 
</script>
<!-- //for-mobile-apps -->
<!-- js -->
<script type="text/javascript" src="<?php echo base_url();?>/site_assets/js/jquery.min.js"></script>
<!-- js -->
<!-- script for close -->
	<script>
		$(document).ready(function(c) {
			$('.alert-close').on('click', function(c){
				$('.vlcone').fadeOut('slow', function(c){
					$('.vlcone').remove();
				});
			});	  
		});
	</script>
	<script>$(document).ready(function(c) {
			$('.alert-close1').on('click', function(c){
				$('.vlctwo').fadeOut('slow', function(c){
					$('.vlctwo').remove();
				});
			});	  
		});
	</script>
	<!-- //script for close -->
<!-- script for etalage -->
<!-- FlexSlider -->
  <script defer src="<?php echo base_url();?>/site_assets/js/jquery.flexslider.js"></script>
<link rel="stylesheet" href="<?php echo base_url();?>/site_assets/css/flexslider.css" type="text/css" media="screen" />
<script>
// Can also be used with $(document).ready()
$(window).load(function() {
  $('.flexslider').flexslider({
    animation: "slide",
    controlNav: "thumbnails"
  });
});
</script>
<!-- //script for etalage -->
</head>
<body>
<!-- content -->
<div class="content">
	<div class="container">
		<div class="nav-top-header">
			<h1><a href=""><!--<img src="images/logo.jpg" width="100%"/>-->
            <img src="<?php echo base_url();?>/site_assets/images/header.jpg" width="100%"/></a></h1>
		</div>
		<div class="navigation text-center">
				<!-- start h_menu4     class="active" -->
				<div class="h_menu4">
					<a class="toggleMenu" href="">Menu</a>
					<ul class="nav">
                    <?php if(isset($menu) && (count($menu) > 0)) {
                        foreach($menu as $m) {                        ?>
						<li><a href="<?php echo base_url().'Dashboard/menu_content/'.$m->id;?>"><?php echo $m->menu_title;?></a>
                        <?php if($m->has_submenu == 1) {
                            echo '<ul>';
                        }?>
						<?php if(isset($submenu) && (count($submenu) > 0)) {
						  foreach($submenu as $sm) {
						      if($sm->menu_id == $m->id) {?>															
								<li><a href="<?php echo base_url().'Dashboard/submenu_content/'.$sm->id;?>"><?php echo $sm->submenu_title;?></a></li>
						<?php }}}?>
						<?php if($m->has_submenu == 1) {
                            echo '</ul>';
                        }?>
						<?php }}?>
                        </li>
					</ul>
						<script type="text/javascript" src="<?php echo base_url();?>/site_assets/js/nav.js"></script>
				</div>
				<!-- end h_menu4 -->
		</div>
		<div class="clearfix"></div>