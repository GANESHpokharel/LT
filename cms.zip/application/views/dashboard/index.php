<?php
error_reporting(0);
session_start();
require_once ('pages/header.php');
//Get all files in pages folder
$files = scandir('pages');
foreach ($files as $f) {
  if (($f != '.') && ($f != '..')) {
    $page_array[] = $f;
  }
}
if (isset($_GET['page'])) {
  if (in_array($_GET['page'], $page_array)) {
    $page = 'pages/' . $_GET['page'];
  } else {
    $page = 'pages/not_found.php';
  }
} else {
  $page = 'pages/home.php';
}
require_once ($page);
require_once ('pages/footer.php');
?>