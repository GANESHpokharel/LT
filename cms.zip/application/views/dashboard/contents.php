<div class="slider-bottom">
<div class="slider-grids">
<div class="slider-left">
<?php if(isset($content) && ($content != null)) {?>
<h3><?php echo $content->title;?></h3>
<?php echo $content->description;?>
<?php if(($content->img1 != '') || ($content->img2 != '')) {?>
    <div class="slider-right text-center">
<img src="" alt="Image"/>
</div>
<?php } ?>
<?php } ?>
</div>
<div class="clearfix"></div>
</div>
</div>