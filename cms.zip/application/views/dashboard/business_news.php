<div class="menu-grid">

<div style="width: 33%; float: left;">
<div class="menu-info">
<h3>Neaplese Economy</h3>
</div>
<ul class="menu_drop">
<?php
$ch = curl_init('http://www.nagariknews.com/economy.feed');
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$r_data = '';
$result = curl_exec($ch);
if ($http_code == 200) {
  $r_data = json_decode($result);
}
curl_close($ch);
$xml = simplexml_load_string($result);
$i = 0;
foreach ($xml->channel->item as $items) {
  echo '<li><a target="_blank" href="' . $items->link . '">' . substr($items->title, 0, 140) .
    '...</a></li>';
  $i++;
  if ($i > 8) {
    break;
  }
}
?>
</ul>
</div>

<div style="width: 33%; float: left;">
<div class="menu-info">
<h3>World Economy</h3>
</div>
<ul class="menu_drop">
<?php
$ch = curl_init('http://rss.cnn.com/rss/money_news_international.rss');
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$r_data = '';
$result = curl_exec($ch);
if ($http_code == 200) {
  $r_data = json_decode($result);
}
curl_close($ch);
$xml = simplexml_load_string($result);
$i = 0;
foreach ($xml->channel->item as $items) {
  echo '<li><a target="_blank" href="' . $items->link . '">' . substr($items->title, 0, 50) .
    '...</a></li>';
  $i++;
  if ($i > 8) {
    break;
  }
}
?>
</ul>
</div>

<div style="width: 33%; float: left;">
<div class="menu-info">
<h3>IFRS News</h3>
</div>
<ul class="menu_drop">
<?php
$ch = curl_init('http://www.iasplus.com/search_rss?portal_type=News+Item&review_state=published&sort_on=getDateAdded&sort_order=descending&Language=en');
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$r_data = '';
$result = curl_exec($ch);
if ($http_code == 200) {
  $r_data = json_decode($result);
}
curl_close($ch);
$xml = simplexml_load_string($result);
$i = 0;
foreach ($xml->item as $items) {
  
  echo '<li><a target="_blank" href="' . $items->link . '">' . substr($items->title, 0, 50) . '...</a></li>';
  $i++;
  if ($i > 8) {
    break;
  }
}
?>
</ul>
</div>

</div>
<div class="clearfix"></div>
