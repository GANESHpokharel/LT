<div class="slider-bottom">
<h3><ul>Our Experiences</ul></h3><br />
<h4><ul>Auditing &amp; Assurance:</ul></h4>
<ul>
<li>Statutory Audit</li>
<li>Internal Audit</li>
<li>Merger &amp; Acquisition Consultancy</li>
<li>Forensic Accounting</li>
</ul><br />
<ul><h4>Information System (IS):</h4></ul>
<ul>
<li>Fraud Investigation</li>
<li>Information System Audit</li>
<li>Microsoft Excel Training</li>
<li>IDEA/CAAT Tools Training</li>
<li>System Migration Audit</li>
<li>System Development Consultancy</li>
<li>Business Continuity Planning (BCP)</li>
<li>Disaster Recovery Planning (DRP)</li>
</ul>
<div class="clearfix"></div>
</div>