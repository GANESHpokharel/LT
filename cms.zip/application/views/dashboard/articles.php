<?php 
$articles = articles();
if((count($articles) > 0) && (isset($articles[$_GET['id'] - 1]))) {
    $article = $articles[$_GET['id'] - 1];
}
?>
<div class="slider-bottom">
<div class="slider-grids">
<h3><?php echo $article['title'];?></h3>
<p><?php echo $article['description'];?></p>
<div class="clearfix"></div>
</div>
</div>