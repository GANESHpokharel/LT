<?php
$all_files = glob('*.png', GLOB_BRACE);
foreach ($all_files as $af) {
  if (substr($af, 0, 8) == 'captcha_') {
    $timestampext = explode('_', $af);
    $timestamp = explode('.', $timestampext[1]);
    //Delete File if the older file is more than 2 minutes old
    if ((time() - $timestamp[0]) > 119) {
      unlink($af);
    }
  }
}
$image = null;
$image = imagecreatetruecolor(200, 50);
if (!$image) {
  echo '<h4 class="message_error">Image True Colour.</h4>';
  return;
}
$background_color = imagecolorallocate($image, 255, 255, 255);
if (!$background_color) {
  echo '<h4 class="message_error">Background Colour.</h4>';
  return;
}
$text_color = imagecolorallocate($image, 0, 255, 255);
if (!$text_color) {
  echo '<h4 class="message_error">Text Colour.</h4>';
  return;
}
$line_color = imagecolorallocate($image, 64, 64, 64);
if (!$line_color) {
  echo '<h4 class="message_error">Line Colour.</h4>';
  return;
}
$pixel_color = imagecolorallocate($image, 0, 0, 255);
if (!$pixel_color) {
  echo '<h4 class="message_error">Pixel Colour.</h4>';
  return;
}
if (imagefilledrectangle($image, 0, 0, 200, 50, $background_color)) {
  for ($i = 0; $i < 3; $i++) {
    if (!imageline($image, 0, rand() % 50, 200, rand() % 50, $line_color)) {
      echo '<h4 class="message_error">Image Line.</h4>';
      return;
    }
  }
  for ($i = 0; $i < 1000; $i++) {
    if (!imagesetpixel($image, rand() % 200, rand() % 50, $pixel_color)) {
      echo '<h4 class="message_error">Image Set Pixel.</h4>';
      return;
    }
  }
  $letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
  $len = strlen($letters);
  $letter = $letters[rand(0, $len - 1)];
  $text_color = imagecolorallocate($image, 1, 1, 1);
  if (!$text_color) {
    echo '<h4 class="message_error">Text Colour.</h4>';
    return;
  }
  $word = "";
  for ($i = 0; $i < 5; $i++) {
    $letter = $letters[rand(0, $len - 1)];
    if (!imagestring($image, 7, 5 + ($i * 30), 20, $letter, $text_color)) {
      echo '<h4 class="message_error">Text Colour.</h4>';
      return;
    }
    $word .= $letter;
  }
  header('Content-type: image/png');
  $name = 'captcha_' . time() . '.png';
  if (imagepng($image, $name)) {
    imagedestroy($image);
    echo '<img src="' . $name .
      '" alt="CAPTCHA" id="captcha"/><input id="text_captcha_code" type="hidden" value="' . $word .
      '" id="text_captcha"/>';
  } else {
    echo '<h4 class="message_error">Captcha Could not be generated. Please Reload Page.</h4>';
    return;
  }
} else {
  echo '<h4 class="message_error">Rectangle Image Fill.</h4>';
  return;
}
?>