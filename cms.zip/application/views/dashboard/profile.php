<div class="slider-bottom">
<!--<div id="top" class="callbacks_container">
<ul class="rslides" id="slider3">
<li>-->
<div class="slider-grids">
<div class="slider-left">
<h3>Profile</h3>
<p>CA. Gokarna Kattel, Being qualified as Chartered Accountant (CA) from The Institute of Chartered Accountants of Nepal (ICAN), Mr. Kattel has experience in Accounting, Auditing, Management and Information Technology field since 2002.</p>
<p>Mr. Kattel has also been qualified as Information System Auditor (ISA) from ICAN with technical collaberation from The Institute of Chartered Accountants of India (ICAI). He has also obtained Licence to conduct Liquidation Business from the Ministry of Industry, Office of Liquidation Administration, Nepal.</p>
<p>Mr. Kattel is well-experienced in the field of Auditing &amp; Assurance of Banks &amp; Financial Institutions, Manufacturing Industries, Casinos, Hospitals, NGOs, Trading Firms, Media, Travel &amp; Tourism Industries, Agricultural Business, Housing Business, Government Owned Companies &amp; Co-operatives. Beside this, he has conducted several Investigations on misappropriation of resources.</p>
</div>
<div class="slider-right text-center">
<img src="" alt="Picture of MR. Gokarna Kattel"/>
</div>
<div class="clearfix"></div>
</div>
<!--</li>
</ul>
</div>-->
</div>