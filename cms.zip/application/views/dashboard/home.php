<div class="slider-bottom">
<img src="<?php echo base_url();?>site_assets/images/home.png" width="100%"/>
<div style="margin-top: 10px;">
<div class="div_left">
Some content in div left
</div>
<div class="div_right">
<div class="menu-info">
<h3>News Atricles</h3>
</div>
<?php if(isset($news_articles) && (count($news_articles) > 0)) {?>
<ul class="menu_drop">
<?php foreach($news_articles as $na) {?>
<li>
<a target="_blank" href="<?php echo base_url().'Dashboard/content/'.$na->id;?>"><?php echo $na->title;?></a>
</li>
<?php }?>
</ul>
<?php }?>
</div>
</div>
<div class="clearfix"></div>
</div>
<style type="text/css">
.div_left {
    border: 1px solid #625548;
    width: 50%;
    float: left;
    padding: 10px;
    min-height: 100px;
}
.div_right {
    width: 50%;
    float: right;
    border: 1px solid #625548;
    padding: 10px;
    min-height: 100px;
}
</style>