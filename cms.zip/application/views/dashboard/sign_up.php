<div class="slider-bottom" style="background: #38761d;">
<h3>Client Information System</h3><br />
<?php if(isset($message)) {
    echo '<h4 class="message_' . $status . '">' . $message . '</h4>';
}?>
<h5><span class="required_f">*</span>Required</h5><br />
<form method="POST" action="<?php echo base_url().'Dashboard/sign_up'?>">
<table>
<tr><td><label>Name: <span class="required_f"><span class="required_f">*</span></span></label></td></tr>
<tr><td><input required="required" type="text" name="name"/></td></tr>

<tr><td><label>Address: <span class="required_f">*</span></label></td></tr>
<tr><td><input required="required" type="text" name="address"/></td></tr>

<tr><td><label>Company Name: <span class="required_f">*</span></label></td></tr>
<tr><td><input required="required" type="text" name="c_name"/></td></tr>

<tr><td><label>E-mail: <span class="required_f">*</span></label></td></tr>
<tr><td><input required="required" type="text" name="email"/></td></tr>

<tr><td><label>Enter the following code: <span class="required_f">*</span><label>(It is case Sensetive.)</label></label></td></tr>
<tr><td>
<span id="captcha-container">
<?php echo $cp_code;?>
</span>
<img id="refresh_image" src="<?php echo base_url();?>site_assets/images/refresh.png" title="Reload Captcha" alt="Refresh"/></td></tr>
<tr><td><input required="required" type="text" name="text_captcha" id="text_captcha"/></td><td id="captcha_message"></td></tr>

<tr><td><input id="submit" type="submit" name="submit" value="Register"/></td></tr>
</table>
</form>
<div class="clearfix"></div>
</div>

<style type="text/css">
.message_success {
    background: #b6d7a8;
    height: 35px;
    border-radius: 5px;
    color: #38761d;
    padding: 7px;
}
.message_error {
    background: #b6d7a8;
    height: 35px;
    border-radius: 5px;
    color: #ce0000;
    padding: 7px;
}
h3,h4,label, .input_value{
    color: #ffffff;
}
h5, .required_f{
    color: #ffd9a8;
}
input[type=text] {
    width: 250px;
}
table tr {
    line-height: 30px;
    margin: 10px;
}
#refresh_image {
    height: 50px;
    width: 50px;
    cursor: pointer;
}
</style>
<script type="text/javascript">
$(document).ready(function() {
    $('#refresh_image').click(function() {
    $('#text_captcha').val('')
    $('#text_captcha_code').val('');
    $('#captcha_message').html('');
    $('#captcha-container').html('');
      $.ajax({
        type: "POST",
        url: '<?php echo base_url().'Dashboard/captcha/jq_ajax';?>',
        success: function(output) {
            $('#captcha').remove();
            $(output).appendTo('#captcha-container');
        }
      });
    });
    $('#text_captcha').keyup(function() {
        if(jQuery(this).val().length == 5) {
            if(jQuery(this).val() == $('#text_captcha_code').val()) {
                $('#captcha_message').html('<h4 class="message_success">Captcha Matches.</h4>');
            } else {
                $('#captcha_message').html('<h4 class="message_error">Captcha Does not Match.</h4>');
            }
        } else {
            $('#captcha_message').html('<h4 class="message_error">Captcha Does not Match.</h4>');
        }
    });
});
</script>