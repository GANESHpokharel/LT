<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Gallery extends CI_Controller {
  public function __construct() {
    parent::__construct();
    $this->load->database();
    $this->load->helper(array(
      'url',
      'html',
      'form'));
    $this->load->library(array(
      'form_validation',
      'session',
      'encrypt'));
    $this->load->model(array(
      'Gallery_model',
      'Album_model',
      'Main_model'));
  }
  public function index() {
    $this->user_access('1', '1');
    $data['title'] = 'Gallery';
    $sdata = $this->session->flashdata('gallery_status');
    if (isset($sdata['status'])) {
      $data['status'] = $sdata['status'];
      $data['message'] = $sdata['message'];
    }
    $data['gallery'] = $this->Gallery_model->retrieve_all();
    $data['album'] = $this->Album_model->retrieve_all();
    $this->load->view('admin/header', $data);
    $this->load->view('admin/sidebar');
    $this->load->view('admin/Gallery');
    $this->load->view('admin/footer');
  }
  public function save() {
    $this->user_access('0', '1');
    $return_data['status'] = 'error';
    $return_data['message'] = 'Unknown Error.';
    if (isset($_POST['submit'])) {
      $img = $_FILES['image'];
      $accept_type = array(
        'image/jpeg' => '.jpg',
        'image/pjpeg' => '.jpg',
        'image/png' => '.png',
        'image/bmp' => '.bmp');
      for ($i = 0; $i < sizeof($img['name']); $i++) {
        if ($img['error'][$i] == 0) {
          //Check filetype
          if (in_array($img['type'][$i], array_keys($accept_type))) {
            $imgname = time() . '_gallery_' . $i . $accept_type[$img['type'][$i]];
            if (move_uploaded_file($img['tmp_name'][$i], 'uploads/image/' . $imgname)) {
              $data = array(
                'album_id' => $this->input->post('album_id'),
                'title' => $this->input->post('title'),
                'image' => $imgname,
                );
              $success = $this->Gallery_model->create($data);
              if ($success) {
                $return_data['status'] = 'success';
                $return_data['message'] = 'Image Uploaded Successfully.';
              } else {
                $return_data['status'] = 'error';
                $return_data['message'] = 'Image could not be Uploaded.';
              }
            } else {
              $return_data['status'] = 'error';
              $return_data['message'] = 'Error in uploading file.';
            }
          } else {
            $return_data['status'] = 'error';
            $return_data['message'] = 'File Type not matched.';
          }
        } else {
          $return_data['status'] = 'error';
          $return_data['message'] = 'Error in file.';
        }
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'No File Submitted.';
    }
    $sdata = $this->session->set_flashdata('gallery_status', $return_data);
    redirect('Gallery', $sdata);
  }
  public function delete($id) {
    $this->user_access('3', '1');
    $data['title'] = 'Gallery';
    if (isset($id)) {
      $image = $this->Gallery_model->retrieve(base64_decode(base64_decode($id)));
      $imagename = $image->image;
      $success = $this->Gallery_model->delete(base64_decode(base64_decode($id)));
      if ($success) {
        //Delete Image
        unlink('uploads/image/' . $imagename);
        $return_data['status'] = 'success';
        $return_data['message'] = 'Image Deleted Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Image could not be Deleted.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'Please Fill up the form correctly.';
    }
    $sdata = $this->session->set_flashdata('gallery_status', $return_data);
    redirect('Gallery', $sdata);
  }
  public function user_access($key, $value) {
    $session = $this->session->all_userdata();
    if (!isset($session['sess_name'])) {
      $this->session->sess_destroy();
      redirect('Login');
    }
    $uaccess = $this->Main_model->retrieve_user_access($session['u_id']);
    $user = 'user_' . $session['u_id'];
    if (count($uaccess) > 0) {
      foreach ($uaccess as $a) {
        $ua[$a->controller] = $a->$user;
      }
    }
    $access = $ua[$this->uri->segment(1)];
    if ($access[$key] != $value) {
      $data['status'] = 'error';
      $data['message'] = 'You Dont have Priviledge';
      $sdata = $this->session->set_flashdata('method_status', $data);
      redirect('Main', $sdata);
    }
  }
}
