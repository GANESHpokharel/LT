<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Document extends CI_Controller {
  public function __construct() {
    parent::__construct();
    $this->load->database();
    $this->load->helper(array(
      'url',
      'html',
      'form'));
    $this->load->library(array(
      'form_validation',
      'session',
      'encrypt'));
    $this->load->model(array('Document_model', 'Main_model'));
  }
  public function index() {
    $this->user_access('1', '1');
    $data['title'] = 'Document';
    $sdata = $this->session->flashdata('document_status');
    if (isset($sdata['status'])) {
      $data['status'] = $sdata['status'];
      $data['message'] = $sdata['message'];
    }
    $data['document'] = $this->Document_model->retrieve_all();
    $this->load->view('admin/header', $data);
    $this->load->view('admin/sidebar');
    $this->load->view('admin/Document');
    $this->load->view('admin/footer');
  }
  public function save() {
    $this->user_access('0', '1');
    $return_data['status'] = 'error';
    $return_data['message'] = 'Unknown Error.';
    if (isset($_POST['submit'])) {
      $doc = $_FILES['doc'];
      $accept_type = array(
        'application/msword' => '.doc',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => '.docx',
        'image/pjpegapplication/pdf' => '.pdf',
        'text/plain' => '.txt',
        );
      for ($i = 0; $i < sizeof($doc['name']); $i++) {
        if ($doc['error'][$i] == 0) {
          //Check filetype
          if (in_array($doc['type'][$i], array_keys($accept_type))) {
            $docname = time() . '_document_' . $i . $accept_type[$doc['type'][$i]];
            if (move_uploaded_file($doc['tmp_name'][$i], 'uploads/docs/' . $docname)) {
              $data = array('title' => $this->input->post('title'), 'document' => $docname);
              $success = $this->Document_model->create($data);
              if ($success) {
                $return_data['status'] = 'success';
                $return_data['message'] = 'Document Uploaded Successfully.';
              } else {
                $return_data['status'] = 'error';
                $return_data['message'] = 'Document could not be Uploaded.';
              }
            } else {
              $return_data['status'] = 'error';
              $return_data['message'] = 'Error in uploading file.';
            }
          } else {
            $return_data['status'] = 'error';
            $return_data['message'] = 'File Type not matched.';
          }
        } else {
          $return_data['status'] = 'error';
          $return_data['message'] = 'Error in file.';
        }
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'No File Submitted.';
    }
    $sdata = $this->session->set_flashdata('document_status', $return_data);
    redirect('Document', $sdata);
  }
  public function delete($id) {
    $this->user_access('3', '1');
    $data['title'] = 'Document';
    if (isset($id)) {
      $document = $this->Document_model->retrieve(base64_decode(base64_decode($id)));
      $docname = $document->document;
      $success = $this->Document_model->delete(base64_decode(base64_decode($id)));
      if ($success) {
        //Delete Document
        unlink('uploads/docs/' . $docname);
        $return_data['status'] = 'success';
        $return_data['message'] = 'Document Deleted Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Document could not be Deleted.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'Please Fill up the form correctly.';
    }
    $sdata = $this->session->set_flashdata('document_status', $return_data);
    redirect('Document', $sdata);
  }
  public function user_access($key, $value) {
    $session = $this->session->all_userdata();
    if (!isset($session['sess_name'])) {
      $this->session->sess_destroy();
      redirect('Login');
    }
    $uaccess = $this->Main_model->retrieve_user_access($session['u_id']);
    $user = 'user_' . $session['u_id'];
    if (count($uaccess) > 0) {
      foreach ($uaccess as $a) {
        $ua[$a->controller] = $a->$user;
      }
    }
    $access = $ua[$this->uri->segment(1)];
    if ($access[$key] != $value) {
      $data['status'] = 'error';
      $data['message'] = 'You Dont have Priviledge';
      $sdata = $this->session->set_flashdata('method_status', $data);
      redirect('Main', $sdata);
    }
  }
}
