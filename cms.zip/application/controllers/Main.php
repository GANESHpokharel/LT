<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Main extends CI_Controller {
  public function __construct() {
    parent::__construct();
    $this->load->database();
    $this->load->helper(array(
      'url',
      'html',
      'form'));
    $this->load->library(array(
      'form_validation',
      'session',
      'encrypt'));
    $this->load->model(array('Main_model', 'Login_model'));
  }
  public function index() {
    $session = $this->session->all_userdata();
    if (!isset($session['sess_name'])) {
      $this->session->sess_destroy();
      redirect('Login');
    }
    $data['title'] = 'Main';
    $data['change_password'] = '0';
    $sdata = $this->session->flashdata('method_status');
    if (isset($sdata['status'])) {
      $data['status'] = $sdata['status'];
      $data['message'] = $sdata['message'];
    }
    $this->load->view('admin/header', $data);
    $this->load->view('admin/sidebar');
    $this->load->view('admin/Main');
    $this->load->view('admin/footer');
  }
  public function manage_users() {
    $this->user_access('0', '1');
    $data['title'] = 'Manage Users';
    $data['manage_user'] = '0';
    $sdata = $this->session->flashdata('method_status');
    if (isset($sdata['status'])) {
      $data['status'] = $sdata['status'];
      $data['message'] = $sdata['message'];
    }
    $data['user'] = $this->Login_model->retrieve_all();
    $session = $this->session->all_userdata();
    $data['u_id'] = $session['u_id'];
    $this->load->view('admin/header', $data);
    $this->load->view('admin/sidebar');
    $this->load->view('admin/Main');
    $this->load->view('admin/footer');
  }
  public function core() {
    $data['title'] = 'Main';
    $this->load->view('admin/header', $data);
    $this->load->view('admin/sidebar');
    $this->load->view('admin/core');
    $this->load->view('admin/footer');
  }
  public function change_password() {
    $this->user_access('2', '1');
    $data['title'] = 'Change Password';
    $data['change_password'] = '1';
    $sdata = $this->session->flashdata('method_status');
    if (isset($sdata['status'])) {
      $data['status'] = $sdata['status'];
      $data['message'] = $sdata['message'];
      if (isset($sdata['user_id'])) {
        $data['user_id'] = $this->Login_model->retrieve_by_id($sdata['user_id']);
      }
      $data['change_password'] = $sdata['change_password'];
    }
    $this->load->view('admin/header', $data);
    $this->load->view('admin/sidebar');
    $this->load->view('admin/Main');
    $this->load->view('admin/footer');
  }
  public function change_user_password($id) {
    $this->user_access('2', '1');
    $data['title'] = 'Change User Password';
    $data['change_password'] = '2';
    $data['user_id'] = $this->Login_model->retrieve_by_id(base64_decode(base64_decode($id)));
    $sdata = $this->session->flashdata('method_status');
    if (isset($sdata['status'])) {
      $data['status'] = $sdata['status'];
      $data['message'] = $sdata['message'];
      $data['change_password'] = $sdata['change_password'];
    }
    $this->load->view('admin/header', $data);
    $this->load->view('admin/sidebar');
    $this->load->view('admin/Main');
    $this->load->view('admin/footer');
  }
  public function check_old_passsword() {
    $this->user_access('1', '1');
    $session = $this->session->all_userdata();
    $data['title'] = 'Change Password';
    if (isset($_POST['submit'])) {
      $cdata = array(
        'username' => $session['sess_name'],
        'password' => $this->input->post('old_password'),
        );
      $success = $this->Login_model->retrieve($cdata);
      if ($success) {
        $return_data['change_password'] = '2';
        $return_data['user_id'] = $session['u_id'];
        $return_data['status'] = 'success';
        $return_data['message'] = 'Please Enter New Password.';
      } else {
        $return_data['change_password'] = '1';
        $return_data['status'] = 'error';
        $return_data['message'] = 'Password is incorrect.';
      }
      $sdata = $this->session->set_flashdata('method_status', $return_data);
      redirect('Main/change_password', $sdata);
    } else {
      redirect('Main');
    }
  }
  public function new_passsword() {
    $this->user_access('2', '1');
    $session = $this->session->all_userdata();
    $data['title'] = 'Change Password';
    if (isset($_POST['submit'])) {
      if ($this->input->post('new_password') == $this->input->post('re_new_password')) {
        $cdata = array(
          'id' => base64_decode(base64_decode($this->input->post('user_id'))),
          'username' => $this->input->post('username'),
          'password' => md5($this->input->post('new_password')),
          );
        $success = $this->Login_model->update($cdata);
        if ($success) {
          $return_data['status'] = 'success';
          $return_data['message'] = 'Password Changed Successfully.';
        } else {
          $return_data['status'] = 'error';
          $return_data['message'] = 'Password could not be changed.';
        }
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Passwords do not match. Try Again';
      }
      $sdata = $this->session->set_flashdata('method_status', $return_data);
      redirect('Main', $sdata);
    } else {
      redirect('Main');
    }
  }
  public function add_user() {
    $this->user_access('0', '1');
    $data['title'] = 'Add User';
    $data['add_user'] = '1';
    $sdata = $this->session->flashdata('method_status');
    if (isset($sdata['status'])) {
      $data['status'] = $sdata['status'];
      $data['message'] = $sdata['message'];
    }
    $this->load->view('admin/header', $data);
    $this->load->view('admin/sidebar');
    $this->load->view('admin/Main');
    $this->load->view('admin/footer');
  }
  public function add_new_user() {
    $this->user_access('0', '1');
    $data['title'] = 'Add New User';
    if (isset($_POST['submit'])) {
      if ($this->input->post('password') == $this->input->post('re_password')) {
        $cdata = array(
          'username' => $this->input->post('username'),
          'password' => md5($this->input->post('password')),
          );
        $success = $this->Login_model->create($cdata);
        if (($success) && ($success != '')) {
          $this->load->dbforge();
          $userid = 'user_' . (string )$success;
          $column_add = $this->dbforge->add_column('tbl_access', array($userid => array(
              'type' => 'VARCHAR',
              'constraint' => '4',
              'default' => '0000')));
          if ($column_add) {
            $return_data['status'] = 'success';
            $return_data['message'] = 'User Added Successfully.';
          } else {
            $return_data['status'] = 'error';
            $return_data['message'] = 'User could not be added.';
          }
        } else {
          $return_data['status'] = 'error';
          $return_data['message'] = 'User could not be added.';
        }
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Passwords do not match. Try Again';
      }
      $sdata = $this->session->set_flashdata('method_status', $return_data);
      if ($return_data['status'] == 'error') {
        redirect('Main/add_user', $sdata);
      } else {
        redirect('Main/manage_users', $sdata);
      }
    } else {
      redirect('Main');
    }
  }
  public function delete_user($id) {
    $this->user_access('2', '3');
    $data['title'] = 'Delete User';
    $success = $this->Login_model->delete(base64_decode(base64_decode($id)));
    if ($success) {
      $this->load->dbforge();
      $drop = $this->dbforge->drop_column('tbl_access', 'user_' . base64_decode(base64_decode($id)));
      if ($drop) {
        $return_data['status'] = 'success';
        $return_data['message'] = 'User Deleted Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'User could not be deleted.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'User could not be deleted.';
    }
    $sdata = $this->session->set_flashdata('method_status', $return_data);
    redirect('Main/manage_users', $sdata);
  }
  public function manage_files() {
    $this->user_access('3', '1');
    $data['title'] = 'Delete Unused Files';
    //Get List Of all used files
    //The used tables are tbl_contents, tbl_document, tbl_gallery
    $image = array();
    $doc = array();
    $tbl_contents_files = $this->Main_model->tbl_contents_files();
    if (count($tbl_contents_files) > 0) {
      foreach ($tbl_contents_files as $c) {
        if ($c->img1 != '') {
          $image[] = $c->img1;
        }
        if ($c->img2 != '') {
          $image[] = $c->img2;
        }
        if ($c->doc1 != '') {
          $doc[] = $c->doc1;
        }
        if ($c->doc2 != '') {
          $doc[] = $c->doc2;
        }
      }
    }
    $tbl_document = $this->Main_model->tbl_document_files();
    if (count($tbl_document) > 0) {
      foreach ($tbl_document as $d) {
        if ($d->document != '') {
          $doc[] = $d->document;
        }
      }
    }
    $tbl_gallery = $this->Main_model->tbl_gallery_files();
    if (count($tbl_gallery) > 0) {
      foreach ($tbl_gallery as $g) {
        if ($g->image != '') {
          $image[] = $g->image;
        }
      }
    }
    $tbl_contact = $this->Main_model->tbl_contact_files();
    if (count($tbl_contact) > 0) {
      foreach ($tbl_contact as $c) {
        if ($c->image != '') {
          $image[] = $c->image;
        }
      }
    }
    //Now delete all files except above listed in directories uploads/image and uploads/docs
    $image_d = scandir('uploads/image');
    $d_img = array();
    foreach ($image_d as $id) {
      if (($id == '.') || ($id == '..') || ($id == 'index.php')) {
      } else {
        if (!in_array($id, $image)) {
          $d_img[] = $id;
        }
      }
    }
    $doc_d = scandir('uploads/docs');
    $d_doc = array();
    foreach ($doc_d as $dd) {
      if (($dd == '.') || ($dd == '..') || ($dd == 'index.php')) {
      } else {
        if (!in_array($dd, $doc)) {
          $d_doc[] = $dd;
        }
      }
    }
    $tbl_audio = $this->Main_model->tbl_radio();
    if (count($tbl_audio) > 0) {
      foreach ($tbl_audio as $a) {
        if ($a->audio != '') {
          $doc[] = $a->audio;
        }
      }
    }
    $audio_d = scandir('uploads/audio');
    $d_audio = array();
    foreach ($audio_d as $aa) {
      if (($aa == '.') || ($aa == '..') || ($aa == 'index.php')) {
      } else {
        if (!in_array($aa, $doc)) {
          $d_audio[] = $aa;
        }
      }
    }
    $data['manage_files'] = '1';
    $data['image'] = $d_img;
    $data['docs'] = $d_doc;
    $data['audios'] = $d_audio;
    $sdata = $this->session->flashdata('method_status');
    if (isset($sdata['status'])) {
      $data['status'] = $sdata['status'];
      $data['message'] = $sdata['message'];
    }
    $this->load->view('admin/header', $data);
    $this->load->view('admin/sidebar');
    $this->load->view('admin/Main');
    $this->load->view('admin/footer');
  }
  public function delete_image($id) {
    $this->user_access('3', '1');
    $file = str_replace('%20', ' ', $id);
    if (unlink('uploads/image/' . $file)) {
      $return_data['status'] = 'success';
      $return_data['message'] = 'File Deleted Successfully.';
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'File could not be deleted.';
    }
    $sdata = $this->session->set_flashdata('method_status', $return_data);
    redirect('Main/manage_files', $sdata);
  }
  public function delete_doc($id) {
    $this->user_access('3', '1');
    $file = str_replace('%20', ' ', $id);
    if (unlink('uploads/docs/' . $file)) {
      $return_data['status'] = 'success';
      $return_data['message'] = 'File Deleted Successfully.';
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'File could not be deleted.';
    }
    $sdata = $this->session->set_flashdata('method_status', $return_data);
    redirect('Main/manage_files', $sdata);
  }
  public function delete_audio($id) {
    $this->user_access('3', '1');
    $file = str_replace('%20', ' ', $id);
    if (unlink('uploads/audio/' . $file)) {
      $return_data['status'] = 'success';
      $return_data['message'] = 'File Deleted Successfully.';
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'File could not be deleted.';
    }
    $sdata = $this->session->set_flashdata('method_status', $return_data);
    redirect('Main/manage_files', $sdata);
  }
  public function manage_access_table() {
    $this->user_access('0', '1');
    //Get List of controllers
    $controllers = scandir('application/controllers');
    $control = array();
    foreach ($controllers as $c) {
      if (($c != '.') && ($c != '..') && ($c != 'index.php') && ($c != 'Dashboard.php')) {
        $control[] = trim($c, '.php');
      }
    }
    //Get List of controllers in databases
    $db_controllers = $this->Main_model->get_access_list();
    $db_control = array();
    if ($db_controllers != null) {
      foreach ($db_controllers as $dbc) {
        $db_control[] = $dbc->controller;
      }
    }
    $controller_diff = array_diff($control, $db_control);
    //Enter new controllers into database
    if (count($controller_diff) > 0) {
      foreach ($controller_diff as $cd) {
        $data = array('controller' => $cd, 'user_1' => '1111');
        $success = $this->Main_model->add_controller($data);
      }
    }
    $return_data['status'] = 'success';
    $return_data['message'] = 'Controllers List Up To Date.';
    $sdata = $this->session->set_flashdata('method_status', $return_data);
    redirect('Main/manage_users', $sdata);
  }
  public function manage_access($id) {
    $this->user_access('0', '1');
    $data['title'] = 'Manage Access';
    $data['manage_access'] = '1';
    $sdata = $this->session->flashdata('method_status');
    if (isset($sdata['status'])) {
      $data['status'] = $sdata['status'];
      $data['message'] = $sdata['message'];
    }
    $data['user'] = $this->Login_model->retrieve_by_id(base64_decode(base64_decode($id)));
    $data['accesses'] = $this->Main_model->retrieve_user_access(base64_decode(base64_decode($id)));
    $this->load->view('admin/header', $data);
    $this->load->view('admin/sidebar');
    $this->load->view('admin/Main');
    $this->load->view('admin/footer');
  }
  public function update_access() {
    $this->user_access('2', '1');
    $data['title'] = 'Update Access';
    if (isset($_POST['submit'])) {
      $user_id = base64_decode(base64_decode($this->input->post('user_id')));
      //Get List of controllers in databases
      $db_controllers = $this->Main_model->get_access_list();
      $db_control = array();
      if ($db_controllers != null) {
        foreach ($db_controllers as $dbc) {
          $db_control['create'][] = 'create_' . $dbc->controller;
          $db_control['retrieve'][] = 'retrieve_' . $dbc->controller;
          $db_control['update'][] = 'update_' . $dbc->controller;
          $db_control['delete'][] = 'delete_' . $dbc->controller;
        }
        foreach ($db_control['create'] as $cn) {
          if (in_array($cn, array_keys($_POST))) {
            $create[str_replace('create_', '', $cn)] = '1';
          } else {
            $create[str_replace('create_', '', $cn)] = '0';
          }
        }
        foreach ($db_control['retrieve'] as $rn) {
          if (in_array($rn, array_keys($_POST))) {
            $retrieve[str_replace('retrieve_', '', $rn)] = '1';
          } else {
            $retrieve[str_replace('retrieve_', '', $rn)] = '0';
          }
        }
        foreach ($db_control['update'] as $un) {
          if (in_array($un, array_keys($_POST))) {
            $update[str_replace('update_', '', $un)] = '1';
          } else {
            $update[str_replace('update_', '', $un)] = '0';
          }
        }
        foreach ($db_control['delete'] as $dn) {
          if (in_array($dn, array_keys($_POST))) {
            $delete[str_replace('delete_', '', $dn)] = '1';
          } else {
            $delete[str_replace('delete_', '', $dn)] = '0';
          }
        }
        foreach ($db_controllers as $dbc) {
          $controller = $dbc->controller;
          $u_access[$controller] = $create[$controller] . $retrieve[$controller] . $update[$controller] . $delete[$controller];
        }
        $data = array('userid' => $user_id, 'access' => $u_access);
        $update = $this->Main_model->update_access($data);
        if ($update['success'] != null) {
          $return_data['status'] = 'success';
          $return_data['message'] = 'Access Modified Successfully.';
          $sdata = $this->session->set_flashdata('method_status', $return_data);
          redirect('Main/manage_users', $sdata);
        }
        $return_data['status'] = 'error';
        $return_data['message'] = 'Unable to modify access.';
        $sdata = $this->session->set_flashdata('method_status', $return_data);
        redirect('Main/manage_users', $sdata);
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Controllers Could not be loaded.';
        $sdata = $this->session->set_flashdata('method_status', $return_data);
        redirect('Main/manage_users', $sdata);
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'Try Again.';
      $sdata = $this->session->set_flashdata('method_status', $return_data);
      redirect('Main/manage_users', $sdata);
    }
  }
  public function user_access($key, $value) {
    $session = $this->session->all_userdata();
    if (!isset($session['sess_name'])) {
      $this->session->sess_destroy();
      redirect('Login');
    }
    $uaccess = $this->Main_model->retrieve_user_access($session['u_id']);
    $user = 'user_' . $session['u_id'];
    if (count($uaccess) > 0) {
      foreach ($uaccess as $a) {
        $ua[$a->controller] = $a->$user;
      }
    }
    $access = $ua[$this->uri->segment(1)];
    if ($access[$key] != $value) {
      $data['status'] = 'error';
      $data['message'] = 'You Dont have Priviledge';
      $sdata = $this->session->set_flashdata('method_status', $data);
      redirect('Main', $sdata);
    }
  }
}
