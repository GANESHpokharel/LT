<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Radio extends CI_Controller {
  public function __construct() {
    parent::__construct();
    $this->load->database();
    $this->load->helper(array(
      'url',
      'html',
      'form'));
    $this->load->library(array(
      'form_validation',
      'session',
      'encrypt'));
    $this->load->model(array('Main_model', 'Radio_model'));
  }
  public function index() {
    $this->user_access('1', '1');
    $data['title'] = 'Radio';
    $sdata = $this->session->flashdata('radio_status');
    if (isset($sdata['status'])) {
      $data['status'] = $sdata['status'];
      $data['message'] = $sdata['message'];
    }
    $data['radio'] = $this->Radio_model->retrieve_all();
    $this->load->view('admin/header', $data);
    $this->load->view('admin/sidebar');
    $this->load->view('admin/Radio');
    $this->load->view('admin/footer');
  }
  public function save() {
    $this->user_access('0', '1');
    $session = $this->session->all_userdata();
    if (isset($_POST['submit'])) {
      $data = array(
        'created' => time(),
        'changed' => time(),
        'uid' => $session['sess_name'],
        'count' => 0,
        'title' => $this->input->post('title'),
        'subtitle' => $this->input->post('subtitle'),
        'date_and_time' => $this->input->post('date_and_time'),
        'link' => $this->input->post('link'),
        'description' => $this->input->post('description'),
        );
      $success = $this->Radio_model->create($data);
      if ($success) {
        $return_data['status'] = 'success';
        $return_data['message'] = 'Radio Content added Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Radio Content could not be added.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'Please Fill up the form correctly.';
    }
    $sdata = $this->session->set_flashdata('radio_status', $return_data);
    redirect('Radio', $sdata);
  }
  public function edit($id) {
    $this->user_access('2', '1');
    if ($id != '') {
      $data['title'] = 'Edit Radio Content';
      $data['edit'] = '1';
      $data['edit_details'] = $this->Radio_model->retrieve(base64_decode(base64_decode($id)));
      $this->load->view('admin/header', $data);
      $this->load->view('admin/sidebar');
      $this->load->view('admin/Radio');
      $this->load->view('admin/footer');
    } else {
      redirect('Radio');
    }
  }
  public function edit_content() {
    $this->user_access('2', '1');
    $session = $this->session->all_userdata();
    $data['title'] = 'Submenu Content';
    if (isset($_POST['submit'])) {
      $data = array(
        'id' => base64_decode(base64_decode($this->input->post('id'))),
        'changed' => time(),
        'uid' => $session['sess_name'],
        'title' => $this->input->post('title'),
        'subtitle' => $this->input->post('subtitle'),
        'date_and_time' => $this->input->post('date_and_time'),
        'link' => $this->input->post('link'),
        'description' => $this->input->post('description'),
        );
      $success = $this->Radio_model->update($data);
      if ($success) {
        $return_data['status'] = 'success';
        $return_data['message'] = 'Radio Content edited Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Radio Content could not be edited.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'Please Fill up the form correctly.';
    }
    $sdata = $this->session->set_flashdata('radio_status', $return_data);
    redirect('Radio', $sdata);
  }
  public function delete($id) {
    $this->user_access('3', '1');
    if ($id != '') {
      $del_data = $this->Radio_model->retrieve(base64_decode(base64_decode($id)));
      $success = $this->Radio_model->delete(base64_decode(base64_decode($id)));
      if ($success) {
        unlink('uploads/image/' . $del_data->image);
        unlink('uploads/audio/' . $del_data->audio);
        $return_data['status'] = 'success';
        $return_data['message'] = 'Radio Content deleted Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Radio Content could not be deleted.';
      }
      $sdata = $this->session->set_flashdata('radio_status', $return_data);
      redirect('Radio', $sdata);
    } else {
      redirect('Radio');
    }
  }
  public function upload_image() {
    $this->user_access('0', '1');
    $return_data['status'] = 'error';
    $return_data['message'] = 'Unknown Error.';
    if (isset($_POST['submit'])) {
      $db_image = key($_FILES);
      if ($_FILES[$db_image]['error'] == 0) {
        $accept_type = array(
          'image/jpeg' => '.jpg',
          'image/pjpeg' => '.jpg',
          'image/png' => '.png',
          'image/bmp' => '.bmp');
        //Check filetype
        if (in_array($_FILES[$db_image]['type'], array_keys($accept_type))) {
          $imgname = 'content_' . base64_decode(base64_decode($this->input->post('id'))) . '_' . $db_image . $accept_type[$_FILES[$db_image]['type']];
          if (move_uploaded_file($_FILES[$db_image]['tmp_name'], 'uploads/image/' . $imgname)) {
            $data = array(
              'id' => base64_decode(base64_decode($this->input->post('id'))),
              $db_image => $imgname,
              );
            $success = $this->Radio_model->update($data);
            if ($success) {
              $return_data['status'] = 'success';
              $return_data['message'] = 'Image Uploaded Successfully.';
            } else {
              $return_data['status'] = 'error';
              $return_data['message'] = 'Image could not be Uploaded.';
            }
          } else {
            $return_data['status'] = 'error';
            $return_data['message'] = 'Error in uploading file.';
          }
        } else {
          $return_data['status'] = 'error';
          $return_data['message'] = 'File Type not matched.';
        }
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Error in file.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'No File Submitted.';
    }
    $sdata = $this->session->set_flashdata('radio_status', $return_data);
    redirect('Radio', $sdata);
  }
  public function delete_image($id) {
    $this->user_access('3', '1');
    $data['title'] = 'Submenu Content';
    if (isset($id)) {
      $image = $this->Radio_model->retrieve(base64_decode(base64_decode($id)));
      $imagename = $image->image;
      $data = array(
        'id' => base64_decode(base64_decode($id)),
        'image' => '',
        );
      $success = $this->Radio_model->update($data);
      if ($success) {
        //Delete Image
        unlink('uploads/image/' . $imagename);
        $return_data['status'] = 'success';
        $return_data['message'] = 'Image Deleted Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Image could not be Deleted.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'Please Fill up the form correctly.';
    }
    $sdata = $this->session->set_flashdata('radio_status', $return_data);
    redirect('Radio', $sdata);
  }
  public function upload_audio() {
    $this->user_access('0', '1');
    $return_data['status'] = 'error';
    $return_data['message'] = 'Unknown Error.';
    if (isset($_POST['submit'])) {
      $db_audio = key($_FILES);
      if ($_FILES[$db_audio]['error'] == 0) {
        $accept_type = array(
          'audio/mpeg' => '.m2a',
          'audio/mp3' => '.m2a',
          'audio/mpeg3' => '.mp3',
          'audio/x-mpeg-3' => '.mp3',
          );
        //Check filetype
        if (in_array($_FILES[$db_audio]['type'], array_keys($accept_type))) {
          $audioname = 'audio_' . base64_decode(base64_decode($this->input->post('id'))) . '_' . $db_audio .
            '_' . $accept_type[$_FILES[$db_audio]['type']];
          if (move_uploaded_file($_FILES[$db_audio]['tmp_name'], 'uploads/audio/' . $audioname)) {
            $data = array(
              'id' => base64_decode(base64_decode($this->input->post('id'))),
              $db_audio => $audioname,
              );
            $success = $this->Radio_model->update($data);
            if ($success) {
              $return_data['status'] = 'success';
              $return_data['message'] = 'Audio Uploaded Successfully.';
            } else {
              $return_data['status'] = 'error';
              $return_data['message'] = 'Audio could not be Uploaded.';
            }
          } else {
            $return_data['status'] = 'error';
            $return_data['message'] = 'Error in uploading file.';
          }
        } else {
          $return_data['status'] = 'error';
          $return_data['message'] = 'File Type not matched.';
        }
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Error in file.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'No File Submitted.';
    }
    $sdata = $this->session->set_flashdata('radio_status', $return_data);
    redirect('Radio', $sdata);
  }
  public function delete_audio($id) {
    $this->user_access('3', '1');
    $data['title'] = 'Audio Content';
    if (isset($id)) {
      $audio = $this->Radio_model->retrieve(base64_decode(base64_decode($id)));
      $audioname = $audio->audio;
      $data = array(
        'id' => base64_decode(base64_decode($id)),
        'audio' => '',
        );
      $success = $this->Radio_model->update($data);
      if ($success) {
        //Delete Audio
        unlink('uploads/audio/' . $audioname);
        $return_data['status'] = 'success';
        $return_data['message'] = 'Audio Deleted Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Audio could not be Deleted.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'Please Fill up the form correctly.';
    }
    $sdata = $this->session->set_flashdata('radio_status', $return_data);
    redirect('Radio', $sdata);
  }
  public function user_access($key, $value) {
    $session = $this->session->all_userdata();
    if (!isset($session['sess_name'])) {
      $this->session->sess_destroy();
      redirect('Login');
    }
    $uaccess = $this->Main_model->retrieve_user_access($session['u_id']);
    $user = 'user_' . $session['u_id'];
    if (count($uaccess) > 0) {
      foreach ($uaccess as $a) {
        $ua[$a->controller] = $a->$user;
      }
    }
    $access = $ua[$this->uri->segment(1)];
    if ($access[$key] != $value) {
      $data['status'] = 'error';
      $data['message'] = 'You Dont have Priviledge';
      $sdata = $this->session->set_flashdata('method_status', $data);
      redirect('Main', $sdata);
    }
  }
}
