<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Manage_content extends CI_Controller {
  public function __construct() {
    parent::__construct();
    $this->load->database();
    $this->load->helper(array(
      'url',
      'html',
      'form'));
    $this->load->library(array(
      'form_validation',
      'session',
      'encrypt'));
    $this->load->model(array(
      'Main_model',
      'Manage_content_model',
      'Menu_model',
      'Submenu_model',
      'Content_model'));
  }
  public function index() {
    $this->user_access('1', '1');
    $data['title'] = 'Manage Content';
    $sdata = $this->session->flashdata('manage_content_status');
    if (isset($sdata['status'])) {
      $data['status'] = $sdata['status'];
      $data['message'] = $sdata['message'];
    }
    $data['menu'] = $this->Menu_model->retrieve_all();
    $data['menu_s'] = $this->Submenu_model->retrieve_menu_having_submenu();
    $data['submenu'] = $this->Submenu_model->retrieve_all();
    $data['content'] = $this->Content_model->retrieve_all();
    $data['manage_content'] = $this->Manage_content_model->retrieve_all();
    $this->load->view('admin/header', $data);
    $this->load->view('admin/sidebar');
    $this->load->view('admin/Manage_content');
    $this->load->view('admin/footer');
  }
  public function save() {
    $this->user_access('0', '1');
    $session = $this->session->all_userdata();
    if (isset($_POST['submit'])) {
      $data = array(
        'created' => time(),
        'changed' => time(),
        'uid' => $session['sess_name'],
        'view_count' => 0,
        'content_type' => $this->input->post('content_type'),
        'content_id' => $this->input->post('content_id'),
        'title' => $this->input->post('title'),
        'subtitle' => $this->input->post('subtitle'),
        'link' => $this->input->post('link'),
        'description' => $this->input->post('description'),
        );
      $success = $this->Manage_content_model->create($data);
      if ($success) {
        $return_data['status'] = 'success';
        $return_data['message'] = 'Content added Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Content could not be added.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'Please Fill up the form correctly.';
    }
    $sdata = $this->session->set_flashdata('manage_content_status', $return_data);
    redirect('Manage_content', $sdata);
  }
  public function edit($id) {
    $this->user_access('2', '1');
    if ($id != '') {
      $data['title'] = 'Edit Submenu Content';
      $data['menu'] = $this->Menu_model->retrieve_all();
      $data['menu_s'] = $this->Submenu_model->retrieve_menu_having_submenu();
      $data['submenu'] = $this->Submenu_model->retrieve_all();
      $data['content'] = $this->Content_model->retrieve_all();
      $data['edit'] = '1';
      $data['edit_details'] = $this->Manage_content_model->retrieve(base64_decode(base64_decode($id)));
      if ($data['edit_details']->content_type == 'submenu') {
        $smenuid = $data['edit_details']->content_id;
        $menuid = $this->Submenu_model->retrieve($smenuid);
        $menu_id = $menuid->menu_id;
        $data['menu_id'] = $menu_id;
        $data['contents_list'] = $this->Submenu_model->retrieve_by_menuid($menu_id);
      }
      if ($data['edit_details']->content_type == 'menu') {
        $data['contents_list'] = $this->Menu_model->retrieve_all();
      }
      if ($data['edit_details']->content_type == 'content') {
        $data['contents_list'] = $this->Content_model->retrieve_all();
      }
      $this->load->view('admin/header', $data);
      $this->load->view('admin/sidebar');
      $this->load->view('admin/Manage_content');
      $this->load->view('admin/footer');
    } else {
      redirect('Manage_content');
    }
  }
  public function content_list($ismenu, $id) {
    $this->user_access('0', '1');
    $slit = '<option value="">Please Select Content</option>';
    if (($ismenu != '') && ($id != '')) {
      if ($ismenu == 'no') {
        $list = $this->Manage_content_model->retrieve_content($id);
        if (count($list) > 0) {
          $title = $id . '_title';
          foreach ($list as $l) {
            $slit .= '<option value="' . $l->id . '">' . $l->$title . '</option>';
          }
        }
      }
      if ($ismenu == 'yes') {
        $list = $this->Submenu_model->retrieve_by_menuid(base64_decode(base64_decode($id)));
        if (count($list) > 0) {
          $title = 'submenu_title';
          foreach ($list as $l) {
            $slit .= '<option value="' . $l->id . '">' . $l->$title . '</option>';
          }
        }
      }
    }
    echo $slit;
  }
  public function edit_content() {
    $this->user_access('2', '1');
    $session = $this->session->all_userdata();
    $data['title'] = 'Submenu Content';
    if (isset($_POST['submit'])) {
      $data = array(
        'id' => base64_decode(base64_decode($this->input->post('id'))),
        'changed' => time(),
        'uid' => $session['sess_name'],
        'content_type' => $this->input->post('content_type'),
        'content_id' => $this->input->post('content_id'),
        'title' => $this->input->post('title'),
        'subtitle' => $this->input->post('subtitle'),
        'link' => $this->input->post('link'),
        'description' => $this->input->post('description'),
        );
      $success = $this->Manage_content_model->update($data);
      if ($success) {
        $return_data['status'] = 'success';
        $return_data['message'] = 'Content edited Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Content could not be edited.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'Please Fill up the form correctly.';
    }
    $sdata = $this->session->set_flashdata('manage_content_status', $return_data);
    redirect('Manage_content', $sdata);
  }
  public function delete($id) {
    $this->user_access('3', '1');
    if ($id != '') {
      $del_data = $this->Manage_content_model->retrieve(base64_decode(base64_decode($id)));
      $success = $this->Manage_content_model->delete(base64_decode(base64_decode($id)));
      if ($success) {
        unlink('uploads/image/' . $del_data->img1);
        unlink('uploads/image/' . $del_data->img2);
        unlink('uploads/docs/' . $del_data->doc1);
        unlink('uploads/docs/' . $del_data->doc2);
        $return_data['status'] = 'success';
        $return_data['message'] = 'Content deleted Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Content could not be deleted.';
      }
      $sdata = $this->session->set_flashdata('manage_content_status', $return_data);
      redirect('Manage_content', $sdata);
    } else {
      redirect('Manage_content');
    }
  }
  public function upload_img() {
    $this->user_access('0', '1');
    $return_data['status'] = 'error';
    $return_data['message'] = 'Unknown Error.';
    if (isset($_POST['submit'])) {
      $db_image = key($_FILES);
      if ($_FILES[$db_image]['error'] == 0) {
        $accept_type = array(
          'image/jpeg' => '.jpg',
          'image/pjpeg' => '.jpg',
          'image/png' => '.png',
          'image/bmp' => '.bmp');
        //Check filetype
        if (in_array($_FILES[$db_image]['type'], array_keys($accept_type))) {
          $imgname = 'content_' . base64_decode(base64_decode($this->input->post('id'))) . '_' . $db_image . $accept_type[$_FILES[$db_image]['type']];
          if (move_uploaded_file($_FILES[$db_image]['tmp_name'], 'uploads/image/' . $imgname)) {
            $data = array(
              'id' => base64_decode(base64_decode($this->input->post('id'))),
              $db_image => $imgname,
              );
            $success = $this->Manage_content_model->update($data);
            if ($success) {
              $return_data['status'] = 'success';
              $return_data['message'] = 'Image Uploaded Successfully.';
            } else {
              $return_data['status'] = 'error';
              $return_data['message'] = 'Image could not be Uploaded.';
            }
          } else {
            $return_data['status'] = 'error';
            $return_data['message'] = 'Error in uploading file.';
          }
        } else {
          $return_data['status'] = 'error';
          $return_data['message'] = 'File Type not matched.';
        }
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Error in file.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'No File Submitted.';
    }
    $sdata = $this->session->set_flashdata('manage_content_status', $return_data);
    redirect('Manage_content', $sdata);
  }
  public function delete_img($id, $imgid) {
    $this->user_access('3', '1');
    $data['title'] = 'Submenu Content';
    if (isset($id) && isset($imgid)) {
      $image = $this->Manage_content_model->retrieve(base64_decode(base64_decode($id)));
      $imagename = $image->$imgid;
      $data = array(
        'id' => base64_decode(base64_decode($id)),
        $imgid => '',
        );
      $success = $this->Manage_content_model->update($data);
      if ($success) {
        //Delete Image
        unlink('uploads/image/' . $imagename);
        $return_data['status'] = 'success';
        $return_data['message'] = 'Image Deleted Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Image could not be Deleted.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'Please Fill up the form correctly.';
    }
    $sdata = $this->session->set_flashdata('manage_content_status', $return_data);
    redirect('Manage_content', $sdata);
  }
  public function upload_doc() {
    $this->user_access('0', '1');
    $return_data['status'] = 'error';
    $return_data['message'] = 'Unknown Error.';
    if (isset($_POST['submit'])) {
      $db_doc = key($_FILES);
      if ($_FILES[$db_doc]['error'] == 0) {
        $accept_type = array(
          'application/msword' => '.doc',
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => '.docx',
          'image/pjpegapplication/pdf' => '.pdf',
          'text/plain' => '.txt',
          ); //Check filetype
        if (in_array($_FILES[$db_doc]['type'], array_keys($accept_type))) {
          $docname = 'content_' . base64_decode(base64_decode($this->input->post('id'))) . '_' . $db_doc . '_' .
            $accept_type[$_FILES[$db_doc]['type']];
          if (move_uploaded_file($_FILES[$db_doc]['tmp_name'], 'uploads/docs/' . $docname)) {
            $data = array(
              'id' => base64_decode(base64_decode($this->input->post('id'))),
              $db_doc => $docname,
              );
            $success = $this->Manage_content_model->update($data);
            if ($success) {
              $return_data['status'] = 'success';
              $return_data['message'] = 'Document Uploaded Successfully.';
            } else {
              $return_data['status'] = 'error';
              $return_data['message'] = 'Document could not be Uploaded.';
            }
          } else {
            $return_data['status'] = 'error';
            $return_data['message'] = 'Error in uploading file.';
          }
        } else {
          $return_data['status'] = 'error';
          $return_data['message'] = 'File Type not matched.';
        }
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Error in file.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'No File Submitted.';
    }
    $sdata = $this->session->set_flashdata('manage_content_status', $return_data);
    redirect('Manage_content', $sdata);
  }
  public function delete_doc($id, $docid) {
    $this->user_access('3', '1');
    $data['title'] = 'Menu Content';
    if (isset($id) && isset($docid)) {
      $document = $this->Manage_content_model->retrieve(base64_decode(base64_decode($id)));
      $docname = $document->$docid;
      $data = array(
        'id' => base64_decode(base64_decode($id)),
        $docid => '',
        );
      $success = $this->Manage_content_model->update($data);
      if ($success) {
        //Delete Document
        unlink('uploads/docs/' . $docname);
        $return_data['status'] = 'success';
        $return_data['message'] = 'Document Deleted Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Document could not be Deleted.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'Please Fill up the form correctly.';
    }
    $sdata = $this->session->set_flashdata('manage_content_status', $return_data);
    redirect('Manage_content', $sdata);
  }
  public function user_access($key, $value) {
    $session = $this->session->all_userdata();
    if (!isset($session['sess_name'])) {
      $this->session->sess_destroy();
      redirect('Login');
    }
    $uaccess = $this->Main_model->retrieve_user_access($session['u_id']);
    $user = 'user_' . $session['u_id'];
    if (count($uaccess) > 0) {
      foreach ($uaccess as $a) {
        $ua[$a->controller] = $a->$user;
      }
    }
    $access = $ua[$this->uri->segment(1)];
    if ($access[$key] != $value) {
      $data['status'] = 'error';
      $data['message'] = 'You Dont have Priviledge';
      $sdata = $this->session->set_flashdata('method_status', $data);
      redirect('Main', $sdata);
    }
  }
}
