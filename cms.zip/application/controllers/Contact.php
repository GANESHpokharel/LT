<?php
if (!defined('BASEPATH')) {
  exit('No direct script access allowed');
}
class Contact extends CI_Controller {
  public function __construct() {
    parent::__construct();
    $this->load->database();
    $this->load->helper(array(
      'url',
      'html',
      'form'));
    $this->load->library(array(
      'form_validation',
      'session',
      'encrypt'));
    $this->load->model(array('Contact_model', 'Main_model'));
  }
  public function index() {
    $this->user_access('1', '1');
    $data['title'] = 'Contact';
    $sdata = $this->session->flashdata('contact_status');
    if (isset($sdata['status'])) {
      $data['status'] = $sdata['status'];
      $data['message'] = $sdata['message'];
    }
    $data['contact'] = $this->Contact_model->retrieve();
    $this->load->view('admin/header', $data);
    $this->load->view('admin/sidebar');
    $this->load->view('admin/Contact');
    $this->load->view('admin/footer');
  }
  public function update() {
    $this->user_access('2', '1');
    if (isset($_POST['submit'])) {
      $data = array(
        'name' => $this->input->post('name'),
        'c_name' => $this->input->post('c_name'),
        'address1' => $this->input->post('address1'),
        'address2' => $this->input->post('address2'),
        'address3' => $this->input->post('address3'),
        'email' => $this->input->post('email'),
        'phone1' => $this->input->post('phone1'),
        'phone2' => $this->input->post('phone2'),
        'phone3' => $this->input->post('phone3'),
        'fax' => $this->input->post('fax'),
        'website_url' => $this->input->post('website_url'),
        'description' => $this->input->post('description'),
        );
      $success = $this->Contact_model->update($data);
      if ($success) {
        $return_data['status'] = 'success';
        $return_data['message'] = 'Contact Updated Successfully.';
      } else {
        $return_data['status'] = 'success';
        $return_data['message'] = 'Contact could not be Updated.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'Try Again.';
    }
    $sdata = $this->session->set_flashdata('contact_status', $return_data);
    redirect('Contact', $sdata);
  }
  public function update_logo() {
    $this->user_access('2', '1');
    $return_data['status'] = 'error';
    $return_data['message'] = 'Unknown Error.';
    if (isset($_POST['submit'])) {
      $db_image = key($_FILES);
      if ($_FILES[$db_image]['error'] == 0) {
        $accept_type = array(
          'image/jpeg' => '.jpg',
          'image/pjpeg' => '.jpg',
          'image/png' => '.png',
          'image/bmp' => '.bmp');
        //Check filetype
        if (in_array($_FILES[$db_image]['type'], array_keys($accept_type))) {
          $imgname = 'contact_logo' . $accept_type[$_FILES[$db_image]['type']];
          if (move_uploaded_file($_FILES[$db_image]['tmp_name'], 'uploads/image/' . $imgname)) {
            $data = array('image' => $imgname);
            $success = $this->Contact_model->update($data);
            $return_data['status'] = 'success';
            $return_data['message'] = 'Logo Uploaded Successfully.';
          } else {
            $return_data['status'] = 'error';
            $return_data['message'] = 'Error in uploading Logo.';
          }
        } else {
          $return_data['status'] = 'error';
          $return_data['message'] = 'File Type not matched.';
        }
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Error in file.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'No File Submitted.';
    }
    $sdata = $this->session->set_flashdata('contact_status', $return_data);
    redirect('Contact', $sdata);
  }
  public function user_access($key, $value) {
    $session = $this->session->all_userdata();
    if (!isset($session['sess_name'])) {
      $this->session->sess_destroy();
      redirect('Login');
    }
    $uaccess = $this->Main_model->retrieve_user_access($session['u_id']);
    $user = 'user_' . $session['u_id'];
    if (count($uaccess) > 0) {
      foreach ($uaccess as $a) {
        $ua[$a->controller] = $a->$user;
      }
    }
    $access = $ua[$this->uri->segment(1)];
    if ($access[$key] != $value) {
      $data['status'] = 'error';
      $data['message'] = 'You Dont have Priviledge';
      $sdata = $this->session->set_flashdata('method_status', $data);
      redirect('Main', $sdata);
    }
  }
}
