<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {
  public function __construct() {
    parent::__construct();
    $this->load->database();
    $this->load->helper(array(
      'url',
      'html',
      'form'));
    $this->load->library(array(
      'form_validation',
      'session',
      'encrypt'));
    $this->load->model(array('Login_model', 'Main_model'));
  }
  public function index() {
    $data['title'] = 'Login';
    $sdata = $this->session->flashdata('login_status');
    if (isset($sdata['status'])) {
      $data['status'] = $sdata['status'];
      $data['message'] = $sdata['message'];
    }
    $this->load->view('admin/Login', $data);
  }
  public function user_login() {
    if (isset($_POST['submit'])) {
      $data = array(
        'username' => $this->input->post('username'),
        'password' => $this->input->post('password'),
        );
      $success = $this->Login_model->retrieve($data);
      if ($success) {
        //Correct
        $session_data = array('u_id' => $success->id, 'sess_name' => $success->username);
        $this->session->set_userdata($session_data);
        $session = $this->session->all_userdata();
        //Update login status
        $data = array(
          'id' => $success->id,
          'login' => '1',
          'session' => $session['__ci_last_regenerate'],
          );
        $success = $this->Login_model->update($data);
        if ($success) {
          redirect('Main');
        } else {
          $return_data['status'] = 'error';
          $return_data['message'] = 'Try again';
          $sdata = $this->session->set_flashdata('login_status', $return_data);
          redirect('Login', $sdata);
        }
      } else {
        //Wrong
        $return_data['status'] = 'error';
        $return_data['message'] = 'Username or Password is incorrect.';
        $sdata = $this->session->set_flashdata('login_status', $return_data);
        redirect('Login', $sdata);
      }
    }
  }
  public function user_logout() {
    $session = $this->session->all_userdata();
    if (!isset($session['sess_name'])) {
      $this->session->sess_destroy();
      redirect('Login');
    }
    $data = array(
      'id' => $session['u_id'],
      'login' => 0,
      'session' => null,
      );
    $success = $this->Login_model->update($data);
    $this->session->sess_destroy();
    redirect('Login');
  }
  public function user_access($key, $value) {
    $session = $this->session->all_userdata();
    if (!isset($session['sess_name'])) {
      $this->session->sess_destroy();
      redirect('Login');
    }
    $uaccess = $this->Main_model->retrieve_user_access($session['u_id']);
    $user = 'user_' . $session['u_id'];
    if (count($uaccess) > 0) {
      foreach ($uaccess as $a) {
        $ua[$a->controller] = $a->$user;
      }
    }
    $access = $ua[$this->uri->segment(1)];
    if ($access[$key] != $value) {
      $data['status'] = 'error';
      $data['message'] = 'You Dont have Priviledge';
      $sdata = $this->session->set_flashdata('method_status', $data);
      redirect('Main', $sdata);
    }
  }
}
