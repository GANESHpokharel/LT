<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Album extends CI_Controller {
  public function __construct() {
    parent::__construct();
    $this->load->database();
    $this->load->helper(array(
      'url',
      'html',
      'form'));
    $this->load->library(array(
      'form_validation',
      'session',
      'encrypt'));
    $this->load->model(array('Album_model', 'Main_model'));
  }
  public function index() {
    $this->user_access('1', '1');
    $data['title'] = 'Album';
    $sdata = $this->session->flashdata('album_status');
    if (isset($sdata['status'])) {
      $data['status'] = $sdata['status'];
      $data['message'] = $sdata['message'];
    }
    $data['album'] = $this->Album_model->retrieve_all();
    $this->load->view('admin/header', $data);
    $this->load->view('admin/sidebar');
    $this->load->view('admin/Album');
    $this->load->view('admin/footer');
  }
  public function save() {
    $this->user_access('0', '1');
    if (isset($_POST['submit'])) {
      $data = array(
        'album_title' => $this->input->post('album_title'),
        'order' => $this->input->post('order'),
        );
      $success = $this->Album_model->create($data);
      if ($success) {
        $return_data['status'] = 'success';
        $return_data['message'] = 'Album added Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Album could not be added.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'Please Fill up the form correctly.';
    }
    $sdata = $this->session->set_flashdata('album_status', $return_data);
    redirect('Album', $sdata);
  }
  public function edit($id) {
    $this->user_access('2', '1');
    if ($id != '') {
      $data['title'] = 'Edit Album';
      $data['edit'] = '1';
      $data['edit_details'] = $this->Album_model->retrieve(base64_decode(base64_decode($id)));
      $this->load->view('admin/header', $data);
      $this->load->view('admin/sidebar');
      $this->load->view('admin/Album');
      $this->load->view('admin/footer');
    } else {
      redirect('Album');
    }
  }
  public function edit_Album() {
    $this->user_access('2', '1');
    $data['title'] = 'Album';
    if (isset($_POST['submit'])) {
      $data = array(
        'id' => base64_decode(base64_decode($this->input->post('id'))),
        'album_title' => $this->input->post('album_title'),
        'order' => $this->input->post('order'),
        );
      $success = $this->Album_model->update($data);
      if ($success) {
        $return_data['status'] = 'success';
        $return_data['message'] = 'Album edited Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Album could not be edited.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'Please Fill up the form correctly.';
    }
    $sdata = $this->session->set_flashdata('album_status', $return_data);
    redirect('Album', $sdata);
  }
  public function delete($id) {
    $this->user_access('3', '1');
    if ($id != '') {
      $success = $this->Album_model->delete(base64_decode(base64_decode($id)));
      if ($success) {
        $return_data['status'] = 'success';
        $return_data['message'] = 'Album deleted Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Album could not be deleted.';
      }
      $sdata = $this->session->set_flashdata('album_status', $return_data);
      redirect('Album', $sdata);
    } else {
      redirect('Album');
    }
  }
  public function user_access($key, $value) {
    $session = $this->session->all_userdata();
    if (!isset($session['sess_name'])) {
      $this->session->sess_destroy();
      redirect('Login');
    }
    $uaccess = $this->Main_model->retrieve_user_access($session['u_id']);
    $user = 'user_' . $session['u_id'];
    if (count($uaccess) > 0) {
      foreach ($uaccess as $a) {
        $ua[$a->controller] = $a->$user;
      }
    }
    $access = $ua[$this->uri->segment(1)];
    if ($access[$key] != $value) {
      $data['status'] = 'error';
      $data['message'] = 'You Dont have Priviledge';
      $sdata = $this->session->set_flashdata('method_status', $data);
      redirect('Main', $sdata);
    }
  }
}
