<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Member extends CI_Controller {
  public function __construct() {
    parent::__construct();
    $this->load->database();
    $this->load->helper(array(
      'url',
      'html',
      'form'));
    $this->load->library(array(
      'form_validation',
      'session',
      'encrypt'));
    $this->load->model(array('Member_model', 'Main_model'));
  }
  public function index() {
    $this->user_access('1', '1');
    $data['title'] = 'Member';
    $sdata = $this->session->flashdata('member_status');
    if (isset($sdata['status'])) {
      $data['status'] = $sdata['status'];
      $data['message'] = $sdata['message'];
    }
    $data['member'] = $this->Member_model->retrieve_all();
    $this->load->view('admin/header', $data);
    $this->load->view('admin/sidebar');
    $this->load->view('admin/Member');
    $this->load->view('admin/footer');
  }
  public function save() {
    $this->user_access('0', '1');
    if (isset($_POST['submit'])) {
      $data = array(
        'name' => $this->input->post('name'),
        'title' => $this->input->post('title'),
        'designation' => $this->input->post('designation'),
        'description' => $this->input->post('description'),
        'order' => $this->input->post('order'),
        );
      $success = $this->Member_model->create($data);
      if ($success) {
        $return_data['status'] = 'success';
        $return_data['message'] = 'Member added Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Member could not be added.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'Please Fill up the form correctly.';
    }
    $sdata = $this->session->set_flashdata('member_status', $return_data);
    redirect('Member', $sdata);
  }
  public function edit($id) {
    $this->user_access('2', '1');
    if ($id != '') {
      $data['title'] = 'Edit Member';
      $data['edit'] = '1';
      $data['edit_details'] = $this->Member_model->retrieve(base64_decode(base64_decode($id)));
      $this->load->view('admin/header', $data);
      $this->load->view('admin/sidebar');
      $this->load->view('admin/Member');
      $this->load->view('admin/footer');
    } else {
      redirect('Member');
    }
  }
  public function edit_member() {
    $this->user_access('2', '1');
    $data['title'] = 'Member';
    if (isset($_POST['submit'])) {
      $data = array(
        'id' => base64_decode(base64_decode($this->input->post('id'))),
        'name' => $this->input->post('name'),
        'title' => $this->input->post('title'),
        'designation' => $this->input->post('designation'),
        'description' => $this->input->post('description'),
        'order' => $this->input->post('order'),
        );
      $success = $this->Member_model->update($data);
      if ($success) {
        $return_data['status'] = 'success';
        $return_data['message'] = 'Member edited Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Member could not be edited.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'Please Fill up the form correctly.';
    }
    $sdata = $this->session->set_flashdata('member_status', $return_data);
    redirect('Member', $sdata);
  }
  public function delete($id) {
    $this->user_access('3', '1');
    if ($id != '') {
      $delete = $this->Member_model->retrieve(base64_decode(base64_decode($id)));
      $success = $this->Member_model->delete(base64_decode(base64_decode($id)));
      if ($success) {
        unlink('uploads/image/' . $delete->image);
        unlink('uploads/docs/' . $delete->file);
        $return_data['status'] = 'success';
        $return_data['message'] = 'Member deleted Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Member could not be deleted.';
      }
      $sdata = $this->session->set_flashdata('member_status', $return_data);
      redirect('Member', $sdata);
    } else {
      redirect('Member');
    }
  }
  public function upload_image() {
    $this->user_access('0', '1');
    $return_data['status'] = 'error';
    $return_data['message'] = 'Unknown Error.';
    if (isset($_POST['submit'])) {
      $db_image = key($_FILES);
      if ($_FILES[$db_image]['error'] == 0) {
        $accept_type = array(
          'image/jpeg' => '.jpg',
          'image/pjpeg' => '.jpg',
          'image/png' => '.png',
          'image/bmp' => '.bmp');
        //Check filetype
        if (in_array($_FILES[$db_image]['type'], array_keys($accept_type))) {
          $imgname = 'member_' . base64_decode(base64_decode($this->input->post('id'))) . $accept_type[$_FILES[$db_image]['type']];
          if (move_uploaded_file($_FILES[$db_image]['tmp_name'], 'uploads/image/' . $imgname)) {
            $data = array(
              'id' => base64_decode(base64_decode($this->input->post('id'))),
              $db_image => $imgname,
              );
            $success = $this->Member_model->update($data);
            if ($success) {
              $return_data['status'] = 'success';
              $return_data['message'] = 'Image Uploaded Successfully.';
            } else {
              $return_data['status'] = 'error';
              $return_data['message'] = 'Image could not be Uploaded.';
            }
          } else {
            $return_data['status'] = 'error';
            $return_data['message'] = 'Error in uploading file.';
          }
        } else {
          $return_data['status'] = 'error';
          $return_data['message'] = 'File Type not matched.';
        }
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Error in file.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'No File Submitted.';
    }
    $sdata = $this->session->set_flashdata('member_status', $return_data);
    redirect('Member', $sdata);
  }
  public function delete_img($id) {
    $this->user_access('3', '1');
    $data['title'] = 'Submenu Content';
    if (isset($id)) {
      $image = $this->Member_model->retrieve(base64_decode(base64_decode($id)));
      $imagename = $image->image;
      $data = array(
        'id' => base64_decode(base64_decode($id)),
        'image' => '',
        );
      $success = $this->Member_model->update($data);
      if ($success) {
        //Delete Image
        unlink('uploads/image/' . $imagename);
        $return_data['status'] = 'success';
        $return_data['message'] = 'Image Deleted Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Image could not be Deleted.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'Please Fill up the form correctly.';
    }
    $sdata = $this->session->set_flashdata('member_status', $return_data);
    redirect('Member', $sdata);
  }
  public function upload_doc() {
    $this->user_access('0', '1');
    $return_data['status'] = 'error';
    $return_data['message'] = 'Unknown Error.';
    if (isset($_POST['submit'])) {
      $db_doc = key($_FILES);
      if ($_FILES[$db_doc]['error'] == 0) {
        $accept_type = array(
          'application/msword' => '.doc',
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => '.docx',
          'image/pjpegapplication/pdf' => '.pdf',
          'text/plain' => '.txt',
          ); //Check filetype
        if (in_array($_FILES[$db_doc]['type'], array_keys($accept_type))) {
          $docname = 'member_' . base64_decode(base64_decode($this->input->post('id'))) . $accept_type[$_FILES[$db_doc]['type']];
          if (move_uploaded_file($_FILES[$db_doc]['tmp_name'], 'uploads/docs/' . $docname)) {
            $data = array(
              'id' => base64_decode(base64_decode($this->input->post('id'))),
              'file' => $docname,
              );
            $success = $this->Member_model->update($data);
            if ($success) {
              $return_data['status'] = 'success';
              $return_data['message'] = 'Document Uploaded Successfully.';
            } else {
              $return_data['status'] = 'error';
              $return_data['message'] = 'Document could not be Uploaded.';
            }
          } else {
            $return_data['status'] = 'error';
            $return_data['message'] = 'Error in uploading file.';
          }
        } else {
          $return_data['status'] = 'error';
          $return_data['message'] = 'File Type not matched.';
        }
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Error in file.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'No File Submitted.';
    }
    $sdata = $this->session->set_flashdata('member_status', $return_data);
    redirect('Member', $sdata);
  }
  public function delete_doc($id) {
    $this->user_access('3', '1');
    $data['title'] = 'Menu Content';
    if (isset($id)) {
      $document = $this->Member_model->retrieve(base64_decode(base64_decode($id)));
      $docname = $document->file;
      $data = array(
        'id' => base64_decode(base64_decode($id)),
        'file' => '',
        );
      $success = $this->Member_model->update($data);
      if ($success) {
        //Delete Document
        unlink('uploads/docs/' . $docname);
        $return_data['status'] = 'success';
        $return_data['message'] = 'Document Deleted Successfully.';
      } else {
        $return_data['status'] = 'error';
        $return_data['message'] = 'Document could not be Deleted.';
      }
    } else {
      $return_data['status'] = 'error';
      $return_data['message'] = 'Please Fill up the form correctly.';
    }
    $sdata = $this->session->set_flashdata('member_status', $return_data);
    redirect('Member', $sdata);
  }
  public function user_access($key, $value) {
    $session = $this->session->all_userdata();
    if (!isset($session['sess_name'])) {
      $this->session->sess_destroy();
      redirect('Login');
    }
    $uaccess = $this->Main_model->retrieve_user_access($session['u_id']);
    $user = 'user_' . $session['u_id'];
    if (count($uaccess) > 0) {
      foreach ($uaccess as $a) {
        $ua[$a->controller] = $a->$user;
      }
    }
    $access = $ua[$this->uri->segment(1)];
    if ($access[$key] != $value) {
      $data['status'] = 'error';
      $data['message'] = 'You Dont have Priviledge';
      $sdata = $this->session->set_flashdata('method_status', $data);
      redirect('Main', $sdata);
    }
  }
}
