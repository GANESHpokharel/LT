<?php
error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');
class Dashboard extends CI_Controller {
  public function __construct() {
    parent::__construct();
    $this->load->database();
    $this->load->helper(array(
      'url',
      'html',
      'form'));
    $this->load->library('session');
    $this->load->model('Dashboard_model');
  }
  public function index() {
    $data['title'] = 'G Kattel & Associates';
    $data['menu'] = $this->Dashboard_model->retrieve_menu();
    $data['submenu'] = $this->Dashboard_model->retrieve_submenu();
    $data['news_articles'] = $this->Dashboard_model->retrieve_news_articles();
    $data['contact'] = $this->Dashboard_model->retrieve_contact();
    $this->load->view('dashboard/header', $data);
    $this->load->view('dashboard/home');
    $this->load->view('dashboard/footer');
  }
  public function menu_content($id) {
    $sdata = $this->session->flashdata('dashboard_status');
    if (isset($sdata['status'])) {
      $data['status'] = $sdata['status'];
      $data['message'] = $sdata['message'];
    }
    $data['title'] = 'G Kattel & Associates';
    $data['menu'] = $this->Dashboard_model->retrieve_menu();
    $data['submenu'] = $this->Dashboard_model->retrieve_submenu();
    $data['news_articles'] = $this->Dashboard_model->retrieve_news_articles();
    $data['content'] = $this->Dashboard_model->retrieve_menucontent($id);
    $data['contact'] = $this->Dashboard_model->retrieve_contact();
    if (isset($data['content']->link) && ($data['content']->link != '')) {
      if ($data['content']->link == 'sign_up') {
        $data['cp_code'] = $this->captcha('method');
      }
      $page_id = $data['content']->link;
    } else {
      $page_id = 'contents';
    }
    $this->load->view('dashboard/header', $data);
    $this->load->view('dashboard/' . $page_id);
    $this->load->view('dashboard/footer');
  }
  public function submenu_content($id) {
    $data['title'] = 'G Kattel & Associates';
    $data['menu'] = $this->Dashboard_model->retrieve_menu();
    $data['submenu'] = $this->Dashboard_model->retrieve_submenu();
    $data['content'] = $this->Dashboard_model->retrieve_submenucontent($id);
    $data['contact'] = $this->Dashboard_model->retrieve_contact();
    $this->load->view('dashboard/header', $data);
    $this->load->view('dashboard/contents');
    $this->load->view('dashboard/footer');
  }
  public function request_service() {
    $sdata = $this->session->flashdata('dashboard__status');
    if (isset($sdata['status'])) {
      $data['status'] = $sdata['status'];
      $data['message'] = $sdata['message'];
    }
    $data['title'] = 'Request Service';
    $data['menu'] = $this->Dashboard_model->retrieve_menu();
    $data['submenu'] = $this->Dashboard_model->retrieve_submenu();
    $data['contact'] = $this->Dashboard_model->retrieve_contact();
    $this->load->view('dashboard/header', $data);
    $this->load->view('dashboard/request_form');
    $this->load->view('dashboard/footer');
  }
  public function content($id) {
    $data['title'] = 'G Kattel & Associates';
    $data['menu'] = $this->Dashboard_model->retrieve_menu();
    $data['submenu'] = $this->Dashboard_model->retrieve_submenu();
    $data['content'] = $this->Dashboard_model->retrieve_content($id);
    $data['contact'] = $this->Dashboard_model->retrieve_contact();
    $this->load->view('dashboard/header', $data);
    $this->load->view('dashboard/contents');
    $this->load->view('dashboard/footer');
  }
  public function captcha($type) {
    $all_files = scandir(trim($_SERVER['SCRIPT_FILENAME'], 'index.php'));
    foreach ($all_files as $af) {
      if (substr($af, 0, 8) == 'captcha_') {
        $timestampext = explode('_', $af);
        $timestamp = explode('.', $timestampext[1]);
        //Delete File if the older file is more than 2 minutes old
        if ((time() - $timestamp[0]) > 119) {
          unlink($af);
        }
      }
    }
    $image = null;
    $image = imagecreatetruecolor(200, 50);
    if (!$image) {
      $message = '<h4 class="message_error">Image True Colour.</h4>';
    }
    $background_color = imagecolorallocate($image, 255, 255, 255);
    if (!$background_color) {
      $message = '<h4 class="message_error">Background Colour.</h4>';
    }
    $text_color = imagecolorallocate($image, 0, 255, 255);
    if (!$text_color) {
      $message = '<h4 class="message_error">Text Colour.</h4>';
    }
    $line_color = imagecolorallocate($image, 64, 64, 64);
    if (!$line_color) {
      $message = '<h4 class="message_error">Line Colour.</h4>';
    }
    $pixel_color = imagecolorallocate($image, 0, 0, 255);
    if (!$pixel_color) {
      $message = '<h4 class="message_error">Pixel Colour.</h4>';
    }
    if (imagefilledrectangle($image, 0, 0, 200, 50, $background_color)) {
      for ($i = 0; $i < 3; $i++) {
        if (!imageline($image, 0, rand() % 50, 200, rand() % 50, $line_color)) {
          $message = '<h4 class="message_error">Image Line.</h4>';
        }
      }
      for ($i = 0; $i < 1000; $i++) {
        if (!imagesetpixel($image, rand() % 200, rand() % 50, $pixel_color)) {
          $message = '<h4 class="message_error">Image Set Pixel.</h4>';
        }
      }
      $letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
      $len = strlen($letters);
      $letter = $letters[rand(0, $len - 1)];
      $text_color = imagecolorallocate($image, 1, 1, 1);
      if (!$text_color) {
        $message = '<h4 class="message_error">Text Colour.</h4>';
      }
      $word = "";
      for ($i = 0; $i < 5; $i++) {
        $letter = $letters[rand(0, $len - 1)];
        if (!imagestring($image, 7, 5 + ($i * 30), 20, $letter, $text_color)) {
          $message = '<h4 class="message_error">Text Colour.</h4>';
        }
        $word .= $letter;
      }
      $name = 'captcha_' . time() . '.png';
      if (imagepng($image, $name)) {
        imagedestroy($image);
        $message = '<img src="' . base_url() . $name .
          '" alt="CAPTCHA" id="captcha"/><input id="text_captcha_code" name="text_captcha_code" type="hidden" value="' .
          $word . '" id="text_captcha"/>';
      } else {
        $message = '<h4 class="message_error">Captcha Could not be generated. Please Reload Page.</h4>';
      }
    } else {
      $message = '<h4 class="message_error">Rectangle Image Fill.</h4>';
    }
    if ($type == 'jq_ajax') {
      echo $message;
    } else {
      return $message;
    }
  }
  public function sign_up() {
    if (isset($_POST['submit'])) {
      if ($this->input->post('text_captcha_code') == $this->input->post('text_captcha')) {
        $data = array(
          'name' => $this->input->post('name'),
          'address' => $this->input->post('address'),
          'c_name' => $this->input->post('c_name'),
          'email' => $this->input->post('email'),
          );
        $success = $this->Dashboard_model->sign_up($data);
        if ($success) {
          $return_data['message'] = 'You Have Registered Successfully.';
          $return_data['status'] = 'success';
        } else {
          $return_data['message'] = 'Something Went Wrong. Try Again.';
          $return_data['status'] = 'error';
        }
      } else {
        $return_data['message'] = 'Captcha Codes Dont Match.';
        $return_data['status'] = 'error';
      }
      $sdata = $this->session->set_flashdata('dashboard_status', $return_data);
      redirect('Dashboard/menu_content/7', $sdata);
    } else {
      redirect('Dashboard/menu_content/7');
    }
  }
  public function register_service() {
    if (isset($_POST['submit'])) {
      $type = $this->input->post('type');
      if (($this->input->post('type') == 'others') && ($this->input->post('type_d') != '')) {
        $type = $this->input->post('type_d');
      }
      $service_type = $this->input->post('service_type');
      if (($this->input->post('service_type') == 'others') && ($this->input->post('service_type_d') != '')) {
        $service_type = $this->input->post('service_type_d');
      }
      $data = array(
        'name' => $this->input->post('name'),
        'e_name' => $this->input->post('e_name'),
        'type' => $type,
        'service_type' => $service_type,
        'mobile' => $this->input->post('mobile'),
        'office' => $this->input->post('office'),
        'email' => $this->input->post('email'),
        'description' => $this->input->post('description'),
        'confirmation' => $this->input->post('confirmation'),
        );
      $success = $this->Dashboard_model->register_service($data);
      if ($success) {
        $return_data['message'] = 'You Have Requested For Serivce Successfully.';
        $return_data['status'] = 'success';
      } else {
        $return_data['message'] = 'Something Went Wrong. Try Again.';
        $return_data['status'] = 'error';
      }
      $sdata = $this->session->set_flashdata('dashboard__status', $return_data);
      redirect('Dashboard/request_service', $sdata);
    } else {
      redirect('Dashboard/request_service');
    }
  }
}