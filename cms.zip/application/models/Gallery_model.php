<?php
if (!defined('BASEPATH')) {
  exit('No direct script access allowed');
}
if (!class_exists('CI_Model')) {
  class CI_Model extends Model {
  }
}
class Gallery_model extends CI_Model {
  public function __construct() {
    parent::__construct();
  }
  public function create($data) {
    $this->db->insert('tbl_gallery', $data);
    if ($this->db->affected_rows() == 1) {
      return TRUE;
    } else {
      return FALSE;
    }
  }
  public function retrieve($data) {
    $this->db->where('id', $data);
    $query = $this->db->get('tbl_gallery');
    $row = $query->row();
    if ($row != NULL) {
      return $row;
    } else {
      return NULL;
    }
  }
  public function retrieve_all() {
    $this->db->select('*');
    $query = $this->db->get('tbl_gallery');
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return NULL;
    }
  }
  public function update($data) {
    $this->db->where('id', $data['id']);
    $this->db->update('tbl_gallery', $data);
    if ($this->db->affected_rows() == 1) {
      return TRUE;
    } else {
      return FALSE;
    }
  }
  public function delete($data) {
    $this->db->where('id', $data);
    $query = $this->db->delete('tbl_gallery');
    if ($query) {
      return TRUE;
    } else {
      return FALSE;
    }
  }
}
