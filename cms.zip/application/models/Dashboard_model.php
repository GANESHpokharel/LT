<?php
if (!defined('BASEPATH')) {
  exit('No direct script access allowed');
}
if (!class_exists('CI_Model')) {
  class CI_Model extends Model {
  }
}
class Dashboard_model extends CI_Model {
  public function __construct() {
    parent::__construct();
  }
  public function retrieve_menu() {
    $this->db->select('*');
    $query = $this->db->get('tbl_menu');
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return NULL;
    }
  }
  public function retrieve_submenu() {
    $this->db->select('*');
    $query = $this->db->get('tbl_submenu');
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return NULL;
    }
  }
  public function retrieve_news_articles() {
    $this->db->where('content_type', 'content');
    $this->db->where('content_id', 1);
    $query = $this->db->get('tbl_contents');
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return NULL;
    }
  }
  public function retrieve_contact() {
    $query = $this->db->get('tbl_contact');
    $row = $query->row();
    if ($row != NULL) {
      return $row;
    } else {
      return NULL;
    }
  }
  public function retrieve_menucontent($id) {
    $this->db->where('content_type', 'menu');
    $this->db->where('content_id', $id);
    $query = $this->db->get('tbl_contents');
    $row = $query->row();
    if ($row != NULL) {
      return $row;
    } else {
      return NULL;
    }
  }
  public function retrieve_submenucontent($id) {
    $this->db->where('content_type', 'submenu');
    $this->db->where('content_id', $id);
    $query = $this->db->get('tbl_contents');
    $row = $query->row();
    if ($row != NULL) {
      return $row;
    } else {
      return NULL;
    }
  }
  public function retrieve_content($id) {
    $this->db->where('id', $id);
    $query = $this->db->get('tbl_contents');
    $row = $query->row();
    if ($row != NULL) {
      return $row;
    } else {
      return NULL;
    }
  }
  public function sign_up($data) {
    $this->db->insert('tbl_users', $data);
    if ($this->db->affected_rows() == 1) {
      return TRUE;
    } else {
      return FALSE;
    }
  }
  public function register_service($data) {
    $this->db->insert('tbl_request_form', $data);
    if ($this->db->affected_rows() == 1) {
      return TRUE;
    } else {
      return FALSE;
    }
  }
}
