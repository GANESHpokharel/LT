<?php
if (!defined('BASEPATH')) {
  exit('No direct script access allowed');
}
if (!class_exists('CI_Model')) {
  class CI_Model extends Model {
  }
}
class Manage_content_model extends CI_Model {
  public function __construct() {
    parent::__construct();
  }
  public function create($data) {
    $this->db->insert('tbl_contents', $data);
    if ($this->db->affected_rows() == 1) {
      return true;
    } else {
      return false;
    }
  }
  public function retrieve($data) {
    $this->db->where('id', $data);
    $query = $this->db->get('tbl_contents');
    $row = $query->row();
    if ($row != null) {
      $view_update_data = array(
        'id' => $data,
        'view_count' => $row->view_count + 1,
        );
      $this->update($view_update_data);
      return $row;
    } else {
      return null;
    }
  }
  public function retrieve_all() {
    $this->db->select('*');
    $query = $this->db->get('tbl_contents');
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return null;
    }
  }
  public function retrieve_content($type) {
    $this->db->select('*');
    $query = $this->db->get('tbl_' . $type);
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return null;
    }
  }
  public function update($data) {
    $this->db->where('id', $data['id']);
    $this->db->update('tbl_contents', $data);
    if ($this->db->affected_rows() == 1) {
      return true;
    } else {
      return false;
    }
  }
  public function delete($data) {
    $this->db->where('id', $data);
    $query = $this->db->delete('tbl_contents');
    if ($query) {
      return true;
    } else {
      return false;
    }
  }
}
