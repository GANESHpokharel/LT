<?php
if (!defined('BASEPATH')) {
  exit('No direct script access allowed');
}
if (!class_exists('CI_Model')) {
  class CI_Model extends Model {
  }
}
class Login_model extends CI_Model {
  public function __construct() {
    parent::__construct();
  }
  public function create($data) {
    $query = $this->db->insert('tbl_user', $data);
    if ($this->db->affected_rows() == 1) {
      return $this->db->insert_id();
    } else {
      return false;
    }
  }
  public function retrieve($data) {
    $this->db->where('username', $data['username']);
    $this->db->where('password', md5($data['password']));
    $query = $this->db->get('tbl_user');
    if ($query->num_rows() > 0) {
      return $query->row();
    } else {
      return false;
    }
  }
  public function retrieve_all() {
    $this->db->select('*');
    $query = $this->db->get('tbl_user');
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return null;
    }
  }
  public function retrieve_by_id($data) {
    $this->db->where('id', $data);
    $query = $this->db->get('tbl_user');
    if ($query->num_rows() > 0) {
      return $query->row();
    } else {
      return null;
    }
  }
  public function update($data) {
    $this->db->where('id', $data['id']);
    $query = $this->db->update('tbl_user', $data);
    if ($this->db->affected_rows() == 1) {
      return true;
    } else {
      return false;
    }
  }
  public function delete($id) {
    $this->db->where('id', $id);
    $query = $this->db->delete('tbl_user');
    if ($this->db->affected_rows() == 1) {
      return true;
    } else {
      return false;
    }
  }
}
