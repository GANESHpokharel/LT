<?php
if (!defined('BASEPATH')) {
  exit('No direct script access allowed');
}
if (!class_exists('CI_Model')) {
  class CI_Model extends Model {
  }
}
class Contact_model extends CI_Model {
  public function __construct() {
    parent::__construct();
  }
  public function create() {
    $this->db->select('*');
    $query = $this->db->get('tbl_contact');
    if ($query->num_rows() > 0) {
      return TRUE;
    } else {
      return NULL;
    }
  }
  public function retrieve() {
    $this->db->select('*');
    $query = $this->db->get('tbl_contact');
    if ($query->num_rows() > 0) {
      return $query->row();
    } else {
      return null;
    }
  }
  public function update($data) {
    $this->db->update('tbl_contact', $data);
    if ($this->db->affected_rows() == 1) {
      return TRUE;
    } else {
      return FALSE;
    }
  }
  public function delete($id) {
    $this->db->where('id', $id);
    $query = $this->db->delete('tbl_contact');
    if ($query) {
      return TRUE;
    } else {
      return FALSE;
    }
  }
}
