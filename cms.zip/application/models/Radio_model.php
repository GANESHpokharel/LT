<?php
if (!defined('BASEPATH')) {
  exit('No direct script access allowed');
}
if (!class_exists('CI_Model')) {
  class CI_Model extends Model {
  }
}
class Radio_model extends CI_Model {
  public function __construct() {
    parent::__construct();
  }
  public function create($data) {
    $this->db->insert('tbl_radio', $data);
    if ($this->db->affected_rows() == 1) {
      return true;
    } else {
      return false;
    }
  }
  public function retrieve($data) {
    $this->db->where('id', $data);
    $query = $this->db->get('tbl_radio');
    $row = $query->row();
    if ($row != null) {
      $update_data = array(
        'id' => $data,
        'count' => $row->count + 1,
        );
      $this->update($update_data);
      return $row;
    } else {
      return null;
    }
  }
  public function retrieve_all() {
    $this->db->select('*');
    $query = $this->db->get('tbl_radio');
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return null;
    }
  }
  public function retrieve_content($type) {
    $this->db->select('*');
    $query = $this->db->get('tbl_' . $type);
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return null;
    }
  }
  public function update($data) {
    $this->db->where('id', $data['id']);
    $this->db->update('tbl_radio', $data);
    if ($this->db->affected_rows() == 1) {
      return true;
    } else {
      return false;
    }
  }
  public function delete($data) {
    $this->db->where('id', $data);
    $query = $this->db->delete('tbl_radio');
    if ($query) {
      return true;
    } else {
      return false;
    }
  }
}
