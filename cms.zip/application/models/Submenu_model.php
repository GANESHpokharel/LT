<?php
if (!defined('BASEPATH')) {
  exit('No direct script access allowed');
}
if (!class_exists('CI_Model')) {
  class CI_Model extends Model {
  }
}
class Submenu_model extends CI_Model {
  public function __construct() {
    parent::__construct();
  }
  public function create($data) {
    $this->db->insert('tbl_submenu', $data);
    if ($this->db->affected_rows() == 1) {
      return TRUE;
    } else {
      return FALSE;
    }
  }
  public function retrieve($data) {
    $this->db->where('id', $data);
    $query = $this->db->get('tbl_submenu');
    $row = $query->row();
    if ($row != NULL) {
      return $row;
    } else {
      return NULL;
    }
  }
  public function retrieve_menu_having_submenu() {
    $this->db->where('has_submenu', '1');
    $query = $this->db->get('tbl_menu');
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return NULL;
    }
  }
  public function retrieve_by_menuid($data) {
    $this->db->where('menu_id', $data);
    $query = $this->db->get('tbl_submenu');
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return NULL;
    }
  }
  public function retrieve_all() {
    $this->db->select('*');
    $query = $this->db->get('tbl_submenu');
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return NULL;
    }
  }
  public function update($data) {
    $this->db->where('id', $data['id']);
    $this->db->update('tbl_submenu', $data);
    if ($this->db->affected_rows() == 1) {
      return TRUE;
    } else {
      return FALSE;
    }
  }
  public function delete($data) {
    $this->db->where('id', $data);
    $query = $this->db->delete('tbl_submenu');
    if ($query) {
      return TRUE;
    } else {
      return FALSE;
    }
  }
}
