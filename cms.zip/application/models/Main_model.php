<?php
if (!defined('BASEPATH')) {
  exit('No direct script access allowed');
}
if (!class_exists('CI_Model')) {
  class CI_Model extends Model {
  }
}
class Main_model extends CI_Model {
  public function __construct() {
    parent::__construct();
  }
  public function tbl_contents_files() {
    $this->db->select('*');
    $query = $this->db->get('tbl_contents');
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return NULL;
    }
  }
  public function tbl_document_files() {
    $this->db->select('*');
    $query = $this->db->get('tbl_document');
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return NULL;
    }
  }
  public function tbl_gallery_files() {
    $this->db->select('*');
    $query = $this->db->get('tbl_gallery');
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return NULL;
    }
  }
  public function tbl_radio() {
    $this->db->select('*');
    $query = $this->db->get('tbl_radio');
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return null;
    }
  }
  public function tbl_contact_files() {
    $this->db->select('*');
    $query = $this->db->get('tbl_contact');
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return NULL;
    }
  }
  public function add_controller($data) {
    $this->db->insert('tbl_access', $data);
    if ($this->db->affected_rows() == 1) {
      return TRUE;
    } else {
      return FALSE;
    }
  }
  public function get_access_list() {
    $query = $this->db->get('tbl_access');
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return NULL;
    }
  }
  public function retrieve_user_access($id) {
    $this->db->select(array('controller', 'user_' . $id));
    $query = $this->db->get('tbl_access');
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return NULL;
    }
  }
  public function update_access($data) {
    $success = array();
    $error = array();
    foreach ($data['access'] as $controller => $access) {
      $this->db->set('user_' . $data['userid'], $access);
      $this->db->where('controller', $controller);
      $this->db->update('tbl_access');
      if ($this->db->affected_rows() == 1) {
        $success[] = $controller;
      } else {
        $error[] = $controller;
      }
    }
    return array('success' => $success, 'error' => $error);
  }
}
